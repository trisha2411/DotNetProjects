﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary1.Services;

namespace CalculatorDemoProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AttachViewModel();
        }
        private void AttachViewModel()
        {
            VMMainWindow vmmainwindow = new VMMainWindow();
            this.DataContext = vmmainwindow;
        }

       

        //private void buttonClick(object sender, RoutedEventArgs e)
        //{
        //    Button button = (Button)sender;
        //    if (resultShowText.Text == "0")
        //        resultShowText.Text = button.Content.ToString();
        //    else
        //    {
        //        resultShowText.Text = resultShowText.Text + button.Content.ToString();
        //    }
        //}

        //private void button17_Click(object sender, RoutedEventArgs e)
        //{
        //    string backSpace = resultShowText.Text;

        //    if (backSpace.Length > 1)
        //    {
        //        backSpace = backSpace.Substring(0, backSpace.Length - 1);
        //    }
        //    else
        //    {
        //        backSpace = "0";
        //    }

        //    resultShowText.Text = backSpace;
        //}
       

        

        
    }
}
