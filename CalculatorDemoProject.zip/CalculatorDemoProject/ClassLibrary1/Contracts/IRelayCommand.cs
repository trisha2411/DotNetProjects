﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace ClassLibrary1.Contracts
{
    public interface IRelayCommand : ICommand
    {
    }
}
