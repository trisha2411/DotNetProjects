﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibrary1.Contracts;

namespace ClassLibrary1.Services
{
    public class VMMainWindow : ViewModelBase
    {

        public VMMainWindow()
        { }

        private IRelayCommand number1Command = null;
        public IRelayCommand Number1Command
        {
            get
            {
                if (number1Command == null)
                {
                    number1Command = new RelayCommand(CommandExecutedBy1);
                }
                return number1Command;
            }
        }

        private IRelayCommand number2Command = null;
        public IRelayCommand Number2Command
        {
            get
            {
                if (number2Command == null)
                {
                    number2Command = new RelayCommand(CommandExecutedBy2);
                }
                return number2Command;
            }
        }
        private IRelayCommand number3Command = null;
        public IRelayCommand Number3Command
        {
            get
            {
                if (number3Command == null)
                {
                    number3Command = new RelayCommand(CommandExecutedBy3);
                }
                return number3Command;
            }
        }

        private IRelayCommand number4Command = null;
        public IRelayCommand Number4Command
        {
            get
            {
                if (number4Command == null)
                {
                    number4Command = new RelayCommand(CommandExecutedBy4);
                }
                return number4Command;
            }
        }
        private IRelayCommand number5Command = null;
        public IRelayCommand Number5Command
        {
            get
            {
                if (number5Command == null)
                {
                    number5Command = new RelayCommand(CommandExecutedBy5);
                }
                return number5Command;
            }
        }

        private IRelayCommand number6Command = null;
        public IRelayCommand Number6Command
        {
            get
            {
                if (number6Command == null)
                {
                    number6Command = new RelayCommand(CommandExecutedBy6);
                }
                return number6Command;
            }
        }
        private IRelayCommand number7Command = null;
        public IRelayCommand Number7Command
        {
            get
            {
                if (number7Command == null)
                {
                    number7Command = new RelayCommand(CommandExecutedBy7);
                }
                return number7Command;
            }
        }

        private IRelayCommand number8Command = null;
        public IRelayCommand Number8Command
        {
            get
            {
                if (number8Command == null)
                {
                    number8Command = new RelayCommand(CommandExecutedBy8);
                }
                return number8Command;
            }
        }
        private IRelayCommand number9Command = null;
        public IRelayCommand Number9Command
        {
            get
            {
                if (number9Command == null)
                {
                    number9Command = new RelayCommand(CommandExecutedBy9);
                }
                return number9Command;
            }
        }

        private IRelayCommand number0Command = null;
        public IRelayCommand Number0Command
        {
            get
            {
                if (number0Command == null)
                {
                    number0Command = new RelayCommand(CommandExecutedBy0);
                }
                return number0Command;
            }
        }
        private IRelayCommand numberPointCommand = null;
        public IRelayCommand NumberPointCommand
        {
            get
            {
                if (numberPointCommand == null)
                {
                    numberPointCommand = new RelayCommand(CommandExecutedByPoint);
                }
                return numberPointCommand;
            }
        }
        private IRelayCommand operationPlusCommand = null;
        public IRelayCommand OperationPlusCommand
        {
            get
            {
                if (operationPlusCommand == null)
                {
                    operationPlusCommand = new RelayCommand(CommandExecutedByPlus);
                }
                return operationPlusCommand;
            }
        }
        private IRelayCommand operationMinusCommand = null;
        public IRelayCommand OperationMinusCommand
        {
            get
            {
                if (operationMinusCommand == null)
                {
                    operationMinusCommand = new RelayCommand(CommandExecutedByMinus);
                }
                return operationMinusCommand;
            }
        }
        private IRelayCommand operationDivCommand = null;
        public IRelayCommand OperationDivCommand
        {
            get
            {
                if (operationDivCommand == null)
                {
                    operationDivCommand = new RelayCommand(CommandExecutedByDiv);
                }
                return operationDivCommand;
            }
        }
        private IRelayCommand operationMultiCommand = null;
        public IRelayCommand OperationMultiCommand
        {
            get
            {
                if (operationMultiCommand == null)
                {
                    operationMultiCommand = new RelayCommand(CommandExecutedByMulti);
                }
                return operationMultiCommand;
            }
        }
        private IRelayCommand backSpaceCommand = null;
        public IRelayCommand BackSpaceCommand
        {
            get
            {
                if (backSpaceCommand == null)
                {
                    backSpaceCommand = new RelayCommand(CommandExecutedByBackSpace);
                }
                return backSpaceCommand;
            }
        }
        private IRelayCommand clearCommand = null;
        public IRelayCommand ClearCommand
        {
            get
            {
                if (clearCommand == null)
                {
                    clearCommand = new RelayCommand(CommandExecutedByClear);
                }
                return clearCommand;
            }
        }
        private IRelayCommand operationEqualsCommand = null;
        public IRelayCommand OperationEqualsCommand
        {
            get
            {
                if (operationEqualsCommand == null)
                {
                    operationEqualsCommand = new RelayCommand(CommandExecutedByEquals);
                }
                return operationEqualsCommand;
            }
        }

        private bool isTextBoxEnable = false;
        public bool IsTextBoxEnable
        {
            get { return isTextBoxEnable; }
        }

        private string resultTextOutput = string.Empty;
        public string ResultTextOutput
        {
            get { return resultTextOutput; }
            set
            {
                resultTextOutput = value;
                OnPropertyChanged("ResultTextOutput");
            }
        }

        private double previousValue = 0.0;
        public double PreviousValue
        {
            get { return previousValue; }
            set { previousValue = value; }
        }
        private void CommandExecutedByPlus()
        {
            PreviousValue = Convert.ToDouble(ResultTextOutput);
            ResultTextOutput = string.Empty;
            lastOperator = Operators.Plus.ToString();
        }
        private void CommandExecutedByMinus()
        {
            PreviousValue = Convert.ToDouble(ResultTextOutput);
            ResultTextOutput = string.Empty;
            lastOperator = Operators.Minus.ToString();
        }
        private void CommandExecutedByDiv()
        {
            PreviousValue = Convert.ToDouble(ResultTextOutput);
            ResultTextOutput = string.Empty;
            lastOperator = Operators.Div.ToString();
        }
        private void CommandExecutedByMulti()
        {
            PreviousValue = Convert.ToDouble(ResultTextOutput);
            ResultTextOutput = string.Empty;
            lastOperator = Operators.Multi.ToString();
        }
        private void CommandExecutedByClear()
        {
            ResultTextOutput = "0";
        }
        private void CommandExecutedByBackSpace()
        {
            string s = ResultTextOutput;

            if (s.Length >= 1)
            {
                s = s.Substring(0, s.Length - 1);
            }
            ResultTextOutput = s;
        }
        private string lastOperator = string.Empty;

        private enum Operators
        {
            Plus,
            Minus,
            Multi,
            Div
        }

        private void CommandExecutedByEquals()
        {
            if (!string.IsNullOrEmpty(lastOperator))
            {
                if (lastOperator == Operators.Plus.ToString())
                { ResultTextOutput = (Convert.ToDouble(ResultTextOutput) + PreviousValue).ToString(); }
                else if (lastOperator == Operators.Minus.ToString())
                { ResultTextOutput = (PreviousValue - Convert.ToDouble(ResultTextOutput)).ToString(); }
                else if (lastOperator == Operators.Multi.ToString())
                { ResultTextOutput = (Convert.ToDouble(ResultTextOutput) * PreviousValue).ToString(); }
                else
                { ResultTextOutput = ( PreviousValue/Convert.ToDouble(ResultTextOutput)).ToString(); }

            }
            else
            {
                ResultTextOutput = "0";
            }

        }

        private void CommandExecutedBy1() { CalculatorOutputUpdate(1); }
        private void CommandExecutedBy2() { CalculatorOutputUpdate(2); }
        private void CommandExecutedBy3() { CalculatorOutputUpdate(3); }
        private void CommandExecutedBy4() { CalculatorOutputUpdate(4); }
        private void CommandExecutedBy5() { CalculatorOutputUpdate(5); }
        private void CommandExecutedBy6() { CalculatorOutputUpdate(6); }
        private void CommandExecutedBy7() { CalculatorOutputUpdate(7); }
        private void CommandExecutedBy8() { CalculatorOutputUpdate(8); }
        private void CommandExecutedBy9() { CalculatorOutputUpdate(9); }
        private void CommandExecutedBy0() { CalculatorOutputUpdate(0); }
        private void CommandExecutedByPoint() { CalculatorOutputUpdate("."); }

        private void CalculatorOutputUpdate(int number)
        {
            ResultTextOutput += number.ToString();
        }
        private void CalculatorOutputUpdate(string point)
        {
            ResultTextOutput += point.ToString();
        }
    }
    
}
