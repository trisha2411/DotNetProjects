﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace MathOperationLibrary.Contracts
{
    public interface ICalculatorRelatedTask : ICommand
    {
    }
}
