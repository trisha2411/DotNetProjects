﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MathOperationLibrary.Services
{
    public class VMForCalculatorOperation
    {
        VMForCalculatorOperation()
        {
 
        }

    }
}
