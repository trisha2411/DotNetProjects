﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibrary1.Contracts;
using System.Windows;

namespace ClassLibrary1.Services
{
    public class MainLoginLogicWindow : ViewBaseModel
    {
        
        public MainLoginLogicWindow()
        { }

        private IRelayCommand loginHereCommand = null;
        public IRelayCommand LoginHereCommand
        {
            get
            {
                if (loginHereCommand == null)
                {
                    loginHereCommand = new RelayCommand(CommandExecutedByLoginButton);
                }
                return loginHereCommand;
            }
        }

        private string usernameText;
        public string UsernameText
        {
            get { return usernameText; }
            set
            {
                usernameText = value;
                OnPropertyChanged("UsernameText");
            }
        }

        private string passwordText;
        public string PasswordText
        {
            get { return passwordText; }
            set
            {
                passwordText = value;
                OnPropertyChanged("PasswordText");
            }
        }


        private void CommandExecutedByLoginButton()
        {
           // LoginOutput(usernameText, passwordText);
            if (usernameText == passwordText)
                MessageBox.Show("hii");
        }
        
        //private void LoginOutput(string usernamePass,string passwordPass)
        //{
        //    string username1 = UsernameText;
        //    string password1 = PasswordText;
            
        //}
    }
    
}
