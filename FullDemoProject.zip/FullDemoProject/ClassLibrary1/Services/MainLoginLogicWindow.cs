﻿using ClassLibrary1.Contracts;
using System.Windows;
using System.Configuration;

namespace ClassLibrary1.Services
{
    public class MainLoginLogicWindow : ViewBaseModel
    {
        
        public MainLoginLogicWindow()
        { }

        private IRelayCommand loginHereCommand = null;
        public IRelayCommand LoginHereCommand
        {
            get
            {
                if (loginHereCommand == null)
                {
                    loginHereCommand = new RelayCommand(DoSave);
                }
                return loginHereCommand;
            }
        }

        private string usernameText;
        public string UsernameText
        {
            get { return usernameText; }
            set
            {
                usernameText = value;
                OnPropertyChanged("UsernameText");
            }
        }

        private string passwordText;
        public string PasswordText
        {
            get { return passwordText; }
            set
            {
                passwordText = value;
                OnPropertyChanged("PasswordText");
            }
        }

        private string details;
        public string Details
        {
            get { return details; }
            set
            {
                details = value;
                OnPropertyChanged("Details");
            }
        }

        public Window UserRegistration { get; set; }
        private void DoSave()
        {
            try
            {
                string dbQuery = "SELECT * FROM UserLogin WHERE Username = '" + UsernameText + "' and Password = '" + PasswordText + "'";
                GetDataLayer.Contracts.IGetConnectionService connectionService = new GetDataLayer.Services.GetConnectionService();
                var queryData = connectionService.GetDataTable(ConfigurationManager.ConnectionStrings["myDbConnectionString"].ConnectionString.ToString(), dbQuery);
                if (queryData.Rows.Count > 0)
                {
                    if (UserRegistration != null)
                    {
                        UserRegistration.Show();
                    }
                }
                else
                { MessageBox.Show("InValid User details"); }
            }
            catch { }

            
        }
        
       
    }
    
}
