﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibrary1.Contracts;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Windows.Input;
using System.Windows.Controls;

namespace ClassLibrary1.Services
{
    public enum Gender
    {
        Male, Female
    }

    public enum MaritalStatus
    {
        Married, Unmarried
    }

    public class MainRegistrationModel : ViewBaseModel
    {
        public MainRegistrationModel()
        {
            

        }

        private string usernameText = string.Empty;
        public string UsernameText
        {
            get { return usernameText; }
            set
            {
                usernameText = value;
                OnPropertyChanged("UsernameText");
            }
        }
        private string passwordText = string.Empty;
        public string PasswordText
        {
            get { return passwordText; }
            set
            {
                passwordText = value;
                OnPropertyChanged("PasswordText");
            }
        }

        private string emailText = string.Empty;
        public string EmailText
        {
            get { return emailText; }
            set
            {
                emailText = value;
                OnPropertyChanged("EmailText");
            }
        }

        private string phoneNumberText = string.Empty;
        public string PhoneNumberText
        {
            get { return phoneNumberText; }
            set
            {
                phoneNumberText = value;
                OnPropertyChanged("PhoneNumberText");
            }
        }

        public List<string> ListOfDegree
        {
            get
            {
                List<string> listOfDegree = new List<string>();
                listOfDegree.Add("-select-");
                listOfDegree.Add("Btech");
                listOfDegree.Add("BCOM");
                listOfDegree.Add("BA");
                listOfDegree.Add("MBA");
                listOfDegree.Add("MTECH");
                return listOfDegree;
            }
        }

        private object selectedItem;
        public object SelectedItem
        {
            get { return selectedItem; }
            set
            {
                selectedItem = value;
                OnPropertyChanged("SelectedItem");
            }
        }
        private string selectedDegree = string.Empty;
        public string SelectedDegree
        {
            get { return selectedDegree; }
            set
            {
                selectedDegree = value;
                OnPropertyChanged("SelectedDegree");
            }
        }

        private Gender selectGender;
        public Gender SelectGender
        {
            get { return selectGender; }
            set
            {
                selectGender = value;
                OnPropertyChanged("SelectGender");
            }
        }

        private MaritalStatus selectMaritalStatus;
        public MaritalStatus SelectMaritalStatus
        {
            get { return selectMaritalStatus; }
            set
            {
                selectMaritalStatus = value;
                OnPropertyChanged("SelectMaritalStatus");
            }
        }

        private string editUsernameText = string.Empty;
        public string EditUsernameText
        {
            get { return editUsernameText; }
            set
            {
                editUsernameText = value;
                OnPropertyChanged("EditUsernameText");
            }
        }
        private string editPasswordText = string.Empty;
        public string EditPasswordText
        {
            get { return editPasswordText; }
            set
            {
                editPasswordText = value;
                OnPropertyChanged("EditPasswordText");
            }
        }

        private string editEmailText = string.Empty;
        public string EditEmailText
        {
            get { return editEmailText; }
            set
            {
                editEmailText = value;
                OnPropertyChanged("EditEmailText");
            }
        }

        private string editPhoneNumberText = string.Empty;
        public string EditPhoneNumberText
        {
            get { return editPhoneNumberText; }
            set
            {
                editPhoneNumberText = value;
                OnPropertyChanged("EditPhoneNumberText");
            }
        }

       

        private object editSelectedItem;
        public object EditSelectedItem
        {
            get { return editSelectedItem; }
            set
            {
                editSelectedItem = value;
                OnPropertyChanged("EditSelectedItem");
            }
        }
        private string editSelectedDegree = string.Empty;
        public string EditSelectedDegree
        {
            get { return editSelectedDegree; }
            set
            {
                editSelectedDegree = value;
                OnPropertyChanged("EditSelectedDegree");
            }
        }

        private Gender editSelectGender;
        public Gender EditSelectGender
        {
            get { return editSelectGender; }
            set
            {
                editSelectGender = value;
                OnPropertyChanged("EditSelectGender");
            }
        }

        private MaritalStatus editSelectMaritalStatus;
        public MaritalStatus EditSelectMaritalStatus
        {
            get { return editSelectMaritalStatus; }
            set
            {
                editSelectMaritalStatus = value;
                OnPropertyChanged("EditSelectMaritalStatus");
            }
        }

       

    }
}
