﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibrary1.Contracts;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;

namespace ClassLibrary1.Services
{
    public enum Gender
    {
        Male, Female
    }

    public enum MaritalStatus
    {
        Married, Unmarried
    }

    public class MainRegistrationModel : ViewBaseModel
    {
        public MainRegistrationModel()
        {
            

        }

        private string usernameText = string.Empty;
        public string UsernameText
        {
            get { return usernameText; }
            set
            {
                usernameText = value;
                OnPropertyChanged("UsernameText");
            }
        }
        private string passwordText = string.Empty;
        public string PasswordText
        {
            get { return passwordText; }
            set
            {
                passwordText = value;
                OnPropertyChanged("PasswordText");
            }
        }

        private string emailText = string.Empty;
        public string EmailText
        {
            get { return emailText; }
            set
            {
                emailText = value;
                OnPropertyChanged("EmailText");
            }
        }

        private string phoneNumberText = string.Empty;
        public string PhoneNumberText
        {
            get { return phoneNumberText; }
            set
            {
                phoneNumberText = value;
                OnPropertyChanged("PhoneNumberText");
            }
        }

        public List<string> ListOfDegree
        {
            get
            {
                List<string> listOfDegree = new List<string>();
                listOfDegree.Add("-select-");
                listOfDegree.Add("Btech");
                listOfDegree.Add("BCOM");
                listOfDegree.Add("BA");
                listOfDegree.Add("MBA");
                listOfDegree.Add("MTECH");
                return listOfDegree;
            }
        }

        private string selectedDegree = string.Empty;
        public string SelectedDegree
        {
            get { return selectedDegree; }
            set
            {
                selectedDegree = value;
                OnPropertyChanged("SelectedDegree");
            }
        }

        private Gender selectGender;
        public Gender SelectGender
        {
            get { return selectGender; }
            set
            {
                selectGender = value;
                OnPropertyChanged("SelectGender");
            }
        }

        private MaritalStatus selectMaritalStatus;
        public MaritalStatus SelectMaritalStatus
        {
            get { return selectMaritalStatus; }
            set
            {
                selectMaritalStatus = value;
                OnPropertyChanged("SelectMaritalStatus");
            }
        }


       
       

    }
}
