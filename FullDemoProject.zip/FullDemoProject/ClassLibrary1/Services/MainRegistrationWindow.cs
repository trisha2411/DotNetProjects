﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using ClassLibrary1.Contracts;
using System.Collections.ObjectModel;
using System.Windows;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Data;

namespace ClassLibrary1.Services
{
   


    public class MainRegistrationWindow : MainRegistrationModel
    {
       
        public MainRegistrationWindow()
        {
            
            showDataAtLoadingTime();
           
        }

       
       
        

        private IRelayCommand registerCommand = null;
        public IRelayCommand RegisterCommand
        {
            get
            {
                if (registerCommand == null)
                {
                    registerCommand = new RelayCommand(CommandExecutedByRegister);
                }
                return registerCommand;
            }
        }
        private IRelayCommand editCommand = null;
        public IRelayCommand EditCommand
        {
            get
            {
                if (editCommand == null)
                {
                    editCommand = new RelayCommand(CommandExecutedByEdit);
                }
                return editCommand;
            }
        }

       
         private ObservableCollection<MainRegistrationModel> details;
        public ObservableCollection<MainRegistrationModel> Details
        {
            get
            {
                return details;
            }
            set
            {
                details = value;
                OnPropertyChanged("Details");
            }
        }

        private ObservableCollection<MainRegistrationModel> allDetails;
        public ObservableCollection<MainRegistrationModel> AllDetails
        {
            get
            {
                return allDetails;
            }
            set
            {
                allDetails = value;
                OnPropertyChanged("AllDetails");
            }
        }
 

        private void CommandExecutedByRegister()
        {
                     if ((!String.IsNullOrEmpty(UsernameText)) || (!String.IsNullOrEmpty(PasswordText)) || (!String.IsNullOrEmpty(EmailText)) || (!String.IsNullOrEmpty(PhoneNumberText))||(!String.IsNullOrEmpty(SelectedDegree)))
            {
                string demoUser1 = UsernameText;
                string demoPass = PasswordText;
                string demoMail = EmailText;
                string demoPhone = PhoneNumberText;
                string demoGender = SelectGender.ToString();
                string demoDegree = SelectedDegree;
                string demoStatus = SelectMaritalStatus.ToString();
                string result=String.Empty;
                int input,loop;
                string checkEmail = @"^(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))@"
                                     + @"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				                                [0-9]{1,2}|25[0-5]|2[0-4][0-9])\."
                                     + @"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				                                [0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                                     + @"([a-zA-Z0-9]+[\w-]+\.)+[a-zA-Z]{1}[a-zA-Z0-9-]{1,23})$";
                 bool checkInteger = true;
                string[] isContainsInteger = new string[] { demoUser1 };
                try
                {
                    for (loop = 0; loop <= isContainsInteger.Length; loop++)
                    {
                        if ((isContainsInteger[loop].Contains("0") == true) || (isContainsInteger[loop].Contains("1") == true) || (isContainsInteger[loop].Contains("2") == true)||
                            (isContainsInteger[loop].Contains("3") == true) || (isContainsInteger[loop].Contains("4") == true) || (isContainsInteger[loop].Contains("5") == true)||
                            (isContainsInteger[loop].Contains("6") == true) || (isContainsInteger[loop].Contains("7") == true) || (isContainsInteger[loop].Contains("8") == true)||
                            (isContainsInteger[loop].Contains("9") == true) || (isContainsInteger[loop].Contains("@") == true) || (isContainsInteger[loop].Contains("#") == true)||
                            (isContainsInteger[loop].Contains("!") == true) || (isContainsInteger[loop].Contains("$") == true) || (isContainsInteger[loop].Contains("%") == true)||
                            (isContainsInteger[loop].Contains("^") == true) || (isContainsInteger[loop].Contains("&") == true) || (isContainsInteger[loop].Contains("*") == true)||
                            (isContainsInteger[loop].Contains("|") == true) || (isContainsInteger[loop].Contains("/") == true) || (isContainsInteger[loop].Contains("<") == true)||
                            (isContainsInteger[loop].Contains(">") == true) || (isContainsInteger[loop].Contains(".") == true) || (isContainsInteger[loop].Contains(",") == true))
                        {
                            checkInteger = false;
                          
                        }
                    }
                }
                catch(IndexOutOfRangeException e)
                {}
                

                bool isPhoneContainsString = int.TryParse(demoPhone, out input);

                if (checkInteger == false)
                {
                    MessageBox.Show("Username should not contain any integer value and special symbol");
                }
                else if(!Regex.IsMatch(EmailText,checkEmail))
                {
                    MessageBox.Show("Please enter valid email");
                }
                else if(demoPass.Length<=6)
                {
                    MessageBox.Show("Length of the password must be greater than 6");
                }
                else if (demoPhone.Length > 10)
                {
                    MessageBox.Show("Length of the phone number should not greater than 10 digits");
                }

                else if (isPhoneContainsString == false)
                {
                    MessageBox.Show("Please enter valid phone number");
                }
                else
                {
                    
                    
                    if (Details == null)
                    {
                           
                            Details = new ObservableCollection<MainRegistrationModel>();
                            DatabaseQuery();
                           
                            UsernameText = string.Empty;
                            PasswordText = string.Empty;
                            EmailText = string.Empty;
                            PhoneNumberText = string.Empty;
                            SelectedDegree = ListOfDegree[0];
                       

                    }
                    else
                    {
                           
                            DatabaseQuery();
                            
                            UsernameText = string.Empty;
                            PasswordText = string.Empty;
                            EmailText = string.Empty;
                            PhoneNumberText = string.Empty;
                            SelectedDegree = ListOfDegree[0];
                      

                    }
                    
                }

            }
            else
            {
                MessageBox.Show("Please enter Some values to Proceed");
            }
            

                
            
        }

        private void CommandExecutedByEdit()
        {
            try
            {
                string dbQuery = "SELECT * FROM UserLogin WHERE Username = '" + UsernameText + "' and Password = '" + PasswordText + "'";
                GetDataLayer.Contracts.IGetConnectionService connectionService = new GetDataLayer.Services.GetConnectionService();
                var queryData = connectionService.GetDataTable(ConfigurationManager.ConnectionStrings["myDbConnectionString"].ConnectionString.ToString(), dbQuery);
                if (queryData.Rows.Count > 0)
                {
                    
                }
                else
                { MessageBox.Show("InValid User details"); }
            }
            catch { }
            MessageBox.Show("Hello");
        }
        void showDataAtLoadingTime()
         {
                

            try
            {
                string selectedData = "SELECT * FROM UserRegistration";
                GetDataLayer.Contracts.IGetConnectionService connectionService = new GetDataLayer.Services.GetConnectionService();
                   DataTable queryData = connectionService.GetDataTable(ConfigurationManager.ConnectionStrings["myDbConnectionString"].ConnectionString.ToString(), selectedData);
                   AllDetails = new ObservableCollection<MainRegistrationModel>();
                int countData;

                for (countData = 0; countData < queryData.Rows.Count; countData++)
                {
                    MainRegistrationModel mainReg = new MainRegistrationModel();
                    mainReg.UsernameText = queryData.Rows[countData]["Name"].ToString();
                    mainReg.PasswordText = queryData.Rows[countData]["Password"].ToString();
                    mainReg.EmailText = queryData.Rows[countData]["Email"].ToString();
                    mainReg.PhoneNumberText = queryData.Rows[countData]["PhoneNumber"].ToString();
                    if (queryData.Rows[countData]["Gender"].ToString() == Gender.Female.ToString())
                    {
                        mainReg.SelectGender = Gender.Female;

                    }
                    else
                    {
                        mainReg.SelectGender = Gender.Male;
                    }


                    mainReg.SelectedDegree = queryData.Rows[countData]["Qualification"].ToString();
                    if (queryData.Rows[countData]["MaritalStatus"].ToString() == MaritalStatus.Married.ToString())
                    {
                        mainReg.SelectMaritalStatus = MaritalStatus.Married;

                    }
                    else
                    {
                        mainReg.SelectMaritalStatus = MaritalStatus.Unmarried;
                    }

                    AllDetails.Add(mainReg);

                }


            }
            catch { }
        }

        void DatabaseQuery()
        {
            string insertQuery = "Insert into UserRegistration (Name,Password, Email, PhoneNumber, Qualification, Gender, MaritalStatus) Values ('" + UsernameText + "','" + PasswordText + "','" + EmailText + "','" + PhoneNumberText + "','" + SelectedDegree + "','" + SelectGender + "','" + SelectMaritalStatus + "')";
            string selectedData = "SELECT * FROM UserRegistration  WHERE Name = '" + UsernameText + "'";
             
            try
            {
            GetDataLayer.Contracts.IGetConnectionService connectionService = new GetDataLayer.Services.GetConnectionService();
            connectionService.AddDataToDataTable(ConfigurationManager.ConnectionStrings["myDbConnectionString"].ConnectionString.ToString(), insertQuery);
            DataTable queryData = connectionService.GetDataTable(ConfigurationManager.ConnectionStrings["myDbConnectionString"].ConnectionString.ToString(), selectedData);
            MainRegistrationModel mainReg = new MainRegistrationModel();
            int countData;
           
            for (countData = 0; countData < queryData.Rows.Count; countData++)
            {
                
                mainReg.UsernameText = queryData.Rows[countData]["Name"].ToString();
                mainReg.PasswordText = queryData.Rows[countData]["Password"].ToString();
                mainReg.EmailText = queryData.Rows[countData]["Email"].ToString();
                mainReg.PhoneNumberText = queryData.Rows[countData]["PhoneNumber"].ToString();
                if (queryData.Rows[countData]["Gender"].ToString() == Gender.Female.ToString())
                {
                    mainReg.SelectGender = Gender.Female;

                }
                else
                {
                    mainReg.SelectGender = Gender.Male;
                }


               mainReg. SelectedDegree = queryData.Rows[countData]["Qualification"].ToString();
                if (queryData.Rows[countData]["MaritalStatus"].ToString() == MaritalStatus.Married.ToString())
                {
                    mainReg.SelectMaritalStatus = MaritalStatus.Married;

                }
                else
                {
                    mainReg.SelectMaritalStatus = MaritalStatus.Unmarried;
                }

                Details.Add(mainReg);
                new MainRegistrationWindow();
        
            }
            
                
            }
            catch { }

        }
    }
}
