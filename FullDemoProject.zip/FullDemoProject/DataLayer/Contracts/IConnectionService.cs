﻿using System.Data;

namespace DataLayer.Contracts
{
   public interface IConnectionService
    {
        
        //void OpenSqlConnection(string connectionString);
       DataTable GetDataTable(string connectionString, string dbQuery);
       void AddDataToDataTable(string connectionString, string dbQuery); 
   }
}
