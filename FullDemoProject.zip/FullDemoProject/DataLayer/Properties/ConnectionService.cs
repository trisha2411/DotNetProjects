﻿using System.Data;
using System.Data.SqlClient;
using DataLayer.Contracts;

namespace DataLayer.Services
{
    public class GetConnectionService : IConnectionService
    {
        private SqlConnection sqlConnection = null;
        public DataTable GetDataTable(string connectionString, string dbQuery)
        {
            DataTable dataTable = new DataTable();                
            try
            {
                OpenSqlConnection(connectionString);
                SqlDataAdapter sqlDa = new SqlDataAdapter(dbQuery, sqlConnection);
                sqlDa.Fill(dataTable);
            }
            catch { }
            return dataTable;
        }

        private void OpenSqlConnection(string connectionString)
        {
            //string connectionString = "Data Source=172.32.33.60\\SQLExpress;Initial Catalog=MyFirstApp;User ID=sa;Password=welcome";
            sqlConnection = new SqlConnection(connectionString);
            if(sqlConnection.State== ConnectionState.Closed)
            {sqlConnection.Open();}
        }

    }
}
