﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.Contracts;
using System.Data;
using System.Data.SqlClient;

namespace DataLayer.Services
{
    public class GetConnectionService : IConnectionService
    {
        private SqlConnection getSqlConnection = null;
 

        public DataTable GetDataTable(string connectionString, string dbQuery)
        {
            DataTable dataTable = new DataTable();
            try
            {
                EstablishSqlConnection(connectionString);
                SqlDataAdapter sqlDa = new SqlDataAdapter(dbQuery, getSqlConnection);
                sqlDa.Fill(dataTable);
            }
            catch { }
            return dataTable;


        }
        public void AddDataToDataTable(string connectionString, string dbQuery)
        {
            try
            {
                EstablishSqlConnection(connectionString);
                //SqlDataAdapter sqlDa = new SqlDataAdapter(dbQuery, sqlConnection);
                SqlCommand sqlCmd = new SqlCommand(dbQuery, getSqlConnection);
                int executeResult = sqlCmd.ExecuteNonQuery();
            }
            catch { }     
        }

      

        private void EstablishSqlConnection(string connectionString)
        {
            //string connectionString = "Data Source=172.32.33.60\\SQLExpress;Initial Catalog=MyFirstApp;User ID=sa;Password=welcome";
            getSqlConnection = new SqlConnection(connectionString);
            if (getSqlConnection.State == ConnectionState.Closed)
            { getSqlConnection.Open(); }
        }

    }
}
