﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary1.Services;

namespace FullDemoProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AttachViewModel();
        }
        private void AttachViewModel()
        {
            MainLoginLogicWindow vmmainwindow = new MainLoginLogicWindow();
            vmmainwindow.UserRegistration = new Window1();
            this.DataContext = vmmainwindow;
               
        }

      

      

        
       

       
    }
}
