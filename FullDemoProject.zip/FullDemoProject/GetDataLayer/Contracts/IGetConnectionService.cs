﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace GetDataLayer.Contracts
{
    public interface IGetConnectionService
    {
        DataTable GetDataTable(string connectionString, string dbQuery);
        void AddDataToDataTable(string connectionString, string dbQuery);
    }
}
