﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GetDataLayer.Contracts;
using System.Data.SqlClient;
using System.Data;

namespace GetDataLayer.Services
{
    public class GetConnectionService : IGetConnectionService
    {
        private SqlConnection sqlConnection = null;
        public DataTable GetDataTable(string connectionString, string dbQuery)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OpenSqlConnection(connectionString);
                SqlDataAdapter sqlDa = new SqlDataAdapter(dbQuery, sqlConnection);
                sqlDa.Fill(dataTable);
            }
            catch { }
            return dataTable;
        }
        public void AddDataToDataTable(string connectionString, string dbQuery)
        {
            try
            {
                OpenSqlConnection(connectionString);
                //SqlDataAdapter sqlDa = new SqlDataAdapter(dbQuery, sqlConnection);
                SqlCommand sqlCmd = new SqlCommand(dbQuery, sqlConnection);
                int executeResult = sqlCmd.ExecuteNonQuery();
            }
            catch { }
        }


        private void OpenSqlConnection(string connectionString)
        {
            //string connectionString = "Data Source=172.32.33.60\\SQLExpress;Initial Catalog=MyFirstApp;User ID=sa;Password=welcome";
            sqlConnection = new SqlConnection(connectionString);
            if (sqlConnection.State == ConnectionState.Closed)
            { sqlConnection.Open(); }
        }
    }
}
