﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFirstAppConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Contracts.IMathOperationsConsole mathOperationsConsole = new Services.MathOperationsConsole();
            mathOperationsConsole.ChooseOperations();
        }
    }
}
