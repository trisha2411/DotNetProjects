﻿using System;
using MyFirstAppConsole.Contracts;
using MyFirstAppLibrary.Contracts;
using MyFirstAppLibrary.Services;
using MyFirstAppMessages.Services;

namespace MyFirstAppConsole.Services
{
    public class MathOperationsConsole : IMathOperationsConsole
    {
        
        public void AdditionOperation()
        {
            Console.WriteLine(AppMessages.MsgChooseOperations);
            Console.WriteLine(AppMessages.MsgMathOperations);
            AdditionOfTwoNumbers();
        }

        private void AdditionOfTwoNumbers()
        {
            int number1 = Convert.ToInt32(Console.ReadLine());
            int number2 = Convert.ToInt32(Console.ReadLine());
            IMathOperations mathOperation = new MathOperations();
            int result = mathOperation.Addition(number1, number2);
            Console.WriteLine("Addition result is = " + result);
            Console.ReadLine();
        }

        public void ChooseOperations()
        {
            Console.WriteLine("Welcome to Maths Operataions");
            Console.WriteLine(AppMessages.MsgChooseOperations);
            Console.WriteLine(AppMessages.MsgMathOperations);
        }
    }
}
