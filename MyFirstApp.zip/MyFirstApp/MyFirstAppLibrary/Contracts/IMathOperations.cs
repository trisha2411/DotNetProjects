﻿
namespace MyFirstAppLibrary.Contracts
{
    public interface IMathOperations
    {
        int Addition(int number1, int number2);
        int Addition(int[] numberList);        
    }
}
