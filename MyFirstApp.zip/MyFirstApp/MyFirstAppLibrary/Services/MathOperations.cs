﻿using MyFirstAppLibrary.Contracts;

namespace MyFirstAppLibrary.Services
{
    public class MathOperations : IMathOperations
    {
        public int Addition(int number1, int number2)
        {
            int resultVal = number1 + number2;
            return resultVal;
        }

        public int Addition(int[] numberList)
        {
            int returnVal = 0;
            for (int counter = 0; counter < numberList.Length; counter++)
            {
                returnVal += numberList[counter];
            }
            return returnVal;
        }
    }
}
