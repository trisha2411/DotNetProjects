﻿
namespace MyFirstAppMessages.Services
{
    public class AppMessages
    {
        public const string MsgWelcome = "Welcome to My App world",
            MsgChooseOperations = "Please select below options",
            MsgMathOperations = "1. Addition of 2 Numbers \n2. Addition of Numbers in Array"
            ;
        
    }
}
