﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MathOperationsLibrary.Contract
{
    public interface IMathOperations
    {
        float AddingTwoNumbers(float number1, float number2);
        float AddingThreeNumbers(float number1, float number2, float number3);
        float SubstractingTwoNumbers(float number1, float number2);
        float MultiplicationOfTwoNumbers(float number1, float number2);
        float MultiplicationOfThreeNumbers(float number1, float number2, float number3);
        float DivisionOfNumbers(float numbner1, float number2);
        //void BubbleSort(int length);
        //void ArraySum(int length1, int length2);
       // void CharacterConcatenate(int length);
       // void SumOfElements(int lengthArray);
        //void ConcatenateString(int length);
    }
}
