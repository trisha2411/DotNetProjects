﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MathOperationsLibrary.Contract;

namespace MathOperationsLibrary.Services
{
    public class MathOperations : IMathOperations

    {
        public float AddingTwoNumbers(float number1, float number2)
        {

           return (number1 + number2);
        }

        public float AddingThreeNumbers(float number1, float number2, float number3)
        {

            return (number1 + number2 + number3);
        }


        public float SubstractingTwoNumbers(float number1, float number2)
        {
            return(number1 - number2);
        }

        public float MultiplicationOfTwoNumbers(float number1, float number2)
        {
           return (number1 * number2);
        }

        public float MultiplicationOfThreeNumbers(float number1, float number2, float number3)
        {
            return(number1 * number2 * number3);
        }


        public float DivisionOfNumbers(float numbner1, float number2)
        {
            float outputDiv = 0.0f;
            try
            {
                outputDiv = numbner1 / number2;
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("you entered '0' as a value \n denominator value must not be '0' :{0}", e);
            }

           return outputDiv;
        }
    }
}
