﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagesFolder.Services
{
    public class CommonMessages
    {
        public const string WelcomeMessage = "Welcome to Our Small Application",
                            SuccessMessage = "Successfully Done",
                            ErrorMessage = "please Enter valid input...",
                            WelcomeMessageForOperation = "let's Start operation",
                            MsgChooseOperations = "Please select below options",
                            MsgMathOperations = "1. Addition of 2 Numbers \n2. Addition of Numbers in Array"
            ;
        
       
        
    }
}
