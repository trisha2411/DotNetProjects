﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Contract.IMathOperationsConsole mathOperationsConsole = new Services.MathOperationsConsole();
            mathOperationsConsole.ChooseOperations();

        }
    }
}
