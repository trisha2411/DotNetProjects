﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace MyConsoleApplication
{
    public class Program
    {
        [STAThread]
        public static void Main(string[] args)
        {
            //ThirdDemoProject.MainWindow app = new ThirdDemoProject.MainWindow();
            //((Window)app).Show();
            //Contract.IMathOperationsConsole mathOperationsConsole = new Services.MathOperationsConsole();
            //mathOperationsConsole.ChooseMessages();
            Console.WriteLine("Choose UI Options.\n1. WPF Form\n2. Console");
            int inputOption = Convert.ToInt32(Console.ReadLine());
            Program prg = new Program();
            prg.ChooseUIOptions(inputOption);
            Console.ReadLine();
        }        

        private void ChooseUIOptions(int option)
        {
            if (option == 1)
            {
                ThirdDemoProject.MainWindow app = new ThirdDemoProject.MainWindow();
                ((Window)app).Show();                
            }
            else if (option == 2)
            {
                Contract.IMathOperationsConsole mathOperationsConsole = new Services.MathOperationsConsole();
                mathOperationsConsole.ChooseMessages();
            }
        }

    }
}
