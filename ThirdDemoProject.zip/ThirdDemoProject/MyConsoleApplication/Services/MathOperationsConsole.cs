﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyConsoleApplication.Contract;
using MessagesFolder.Services;
using MathOperationsLibrary.Contract;
using MathOperationsLibrary.Services;

namespace MyConsoleApplication.Services
{
    public class MathOperationsConsole: IMathOperationsConsole
    {
        public void AdditionOperationForTwoNumber()
        {
            Console.WriteLine(CommonMessages.WelcomeMessage);
            Console.WriteLine(CommonMessages.WelcomeMessageForOperation);
            AdditionPerformForTwoNumber();
            Console.WriteLine(CommonMessages.SuccessMessage);
            Console.ReadLine();
        }
        public void AdditionOperationForThreeNumber()
        {
            Console.WriteLine(CommonMessages.WelcomeMessage);
            Console.WriteLine(CommonMessages.WelcomeMessageForOperation);
            AdditionPerformForThreeNumber();
            Console.WriteLine(CommonMessages.SuccessMessage);
            Console.ReadLine();
        }

        private void AdditionPerformForTwoNumber()
        {
            float number1 = Convert.ToInt32(Console.ReadLine());
            float number2 = Convert.ToInt32(Console.ReadLine());
            IMathOperations iMathOperations = new MathOperations();
            float resultAddition = iMathOperations.AddingTwoNumbers(number1, number2);
            Console.WriteLine("Addition of two number is :",resultAddition );
            Console.ReadLine();

        }
        private void AdditionPerformForThreeNumber()
        {
            float number1 = Convert.ToInt32(Console.ReadLine());
            float number2 = Convert.ToInt32(Console.ReadLine());
            float number3 = Convert.ToInt32(Console.ReadLine());
            IMathOperations iMathOperations = new MathOperations();
            float resultAddition = iMathOperations.AddingThreeNumbers(number1, number2,number3);
            Console.WriteLine("Addition of three number is :", resultAddition);
            Console.ReadLine();

        }

      
    }
}
