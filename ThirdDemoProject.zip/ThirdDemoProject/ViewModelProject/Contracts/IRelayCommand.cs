﻿using System.Windows.Input;
namespace ViewModelProject.Contracts
{
    public interface IRelayCommand : ICommand
    {
    }
}
