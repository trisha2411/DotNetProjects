﻿using System.Windows;
using ViewModelProject.Contracts;

namespace ViewModelProject.Services
{
    public class VMMainWindow
    {
        public VMMainWindow()
        { }

        private IRelayCommand wpfCommand = null;
        public IRelayCommand WPFCommand
        {
            get
            {
                if (wpfCommand == null)
                {
                    wpfCommand = new RelayCommand(WPFCommandExecute);
                }
                return wpfCommand;
            }
        }

        private string textInput = string.Empty;
        public string TextInput
        {
            get { return textInput; }
            set { textInput = value; 
            
            }
        }


        private void WPFCommandExecute()
        {
            MessageBox.Show("Input Text value is " + TextInput);
        }

    }
}
