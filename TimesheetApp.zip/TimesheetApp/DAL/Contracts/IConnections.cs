﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace MyApp.DAL.Contracts
{
        public interface IConnections
        {
            string DBConnectionString { get; set; }
            SqlConnection CurrentConnection { get; }
            void OpenSqlConnection();
            void CloseOpenSqlConnection(SqlConnection sqlConnection);
        }
    
}
