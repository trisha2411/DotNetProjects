﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace MyApp.DAL.Contracts
{
     public interface IDataHelper
    {

        string DBConnectionString { get; set; }
        DataTable GetDataTable(string query);
    }
}
