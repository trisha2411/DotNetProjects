﻿
namespace MyApp.DAL.Contracts
{
    public interface ISqlDataService
    {
        string GetColumnsForTable(string[] columnList);
    }
}
