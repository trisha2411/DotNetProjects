﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.DAL.Contracts;
using System.Data.SqlClient;

namespace MyApp.DAL.Services
{
    class Connections : IConnections
    {
        private SqlConnection currentConnection;
        public SqlConnection CurrentConnection
        {
            get { return currentConnection; }
            private set { currentConnection = value; }
        }

        public string DBConnectionString
        { get; set; }

        public void OpenSqlConnection()
        {
            SqlConnection sqlCon = new SqlConnection(DBConnectionString);
            if (sqlCon.State == System.Data.ConnectionState.Closed)
            { sqlCon.Open(); }
            CurrentConnection = sqlCon;
        }
        //public void AddDataToDataTable(string DBConnectionString, string query)
        //{
        //    try
        //    {
        //       OpenSqlConnection(DBConnectionString);
        //       SqlCommand sqlCmd = new SqlCommand(query, currentConnection);
        //        int executeResult = sqlCmd.ExecuteNonQuery();
        //    }
        //    catch { }
        //}
        public void CloseOpenSqlConnection(SqlConnection sqlConnection)
        {
            sqlConnection.Close();
        }
    }
}
