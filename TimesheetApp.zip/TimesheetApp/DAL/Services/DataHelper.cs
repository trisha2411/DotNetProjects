﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.DAL.Contracts;
using System.Data;
using System.Data.SqlClient;

namespace MyApp.DAL.Services
{
   public class DataHelper : IDataHelper
    {
        public string DBConnectionString
        { get; set; }

        public DataTable GetDataTable(string query)
        {
            Connections connections = new Connections();

            connections.DBConnectionString = DBConnectionString;
            connections.OpenSqlConnection();
            SqlCommand sqlCmd = new SqlCommand(query, connections.CurrentConnection);
            int executeResult = sqlCmd.ExecuteNonQuery();
            SqlDataAdapter sqlDA = new SqlDataAdapter(sqlCmd);
            DataTable dtData = new DataTable();
            sqlDA.Fill(dtData);
            connections.CloseOpenSqlConnection(connections.CurrentConnection);
            return dtData;
        }
        

    }
}
