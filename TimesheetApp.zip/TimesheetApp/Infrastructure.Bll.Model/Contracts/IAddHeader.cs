﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
   public interface IAddHeader
    {
        IRelayCommand CommandLogOut { get; set; }
    }
}
