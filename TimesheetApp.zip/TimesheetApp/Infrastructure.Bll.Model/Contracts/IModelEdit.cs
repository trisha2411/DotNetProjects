﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Entity.Services;
using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
    public interface IModelEdit
    {
        DateTime WorkDate { get; set; }
        string WorkHours { get; set; }
        string Name { get; set; }
        string AssignedTeam { get; set; }
        string CompanyCode { get; set; }
        string SowCode { get; set; }
        string ProjectCode { get; set; }
        string ProjectName { get; set; }
        string SubProjectCode { get; set; }
        string Location { get; set; }
        string JiraRef { get; set; }
        string TaskDetails { get; set; }

        ObservableCollection<string> ListAssignedTeams { get; set; }
        ObservableCollection<string> ListCompanies { get; set; }
        ObservableCollection<string> ListLocations { get; set; }
        ObservableCollection<string> ListProjects { get; set; }
        ObservableCollection<string> ListSubProjects { get; set; }
        ObservableCollection<string> ListSow { get; set; }
        ObservableCollection<TimeEntryDetails> ListTimeEntry { get; set; }

       
        IRelayCommand CommandEditTimeEntry { get; set; }
       
    }
}
