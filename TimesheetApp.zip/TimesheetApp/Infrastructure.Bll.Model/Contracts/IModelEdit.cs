﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Entity.Services;
using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
    public interface IModelEdit
    {
        DateTime EditWorkDate { get; set; }
        string EditWorkHours { get; set; }
        string EditName { get; set; }
        string EditAssignedTeam { get; set; }
        string EditCompanyCode { get; set; }
        string EditSowCode { get; set; }
        string EditProjectCode { get; set; }
        string EditProjectName { get; set; }
        string EditSubProjectCode { get; set; }
        string EditLocation { get; set; }
        string EditJiraRef { get; set; }
        string EditTaskDetails { get; set; }

        ObservableCollection<string> ListAssignedTeams { get; set; }
        ObservableCollection<string> ListCompanies { get; set; }
        ObservableCollection<string> ListLocations { get; set; }
        ObservableCollection<string> ListProjects { get; set; }
        ObservableCollection<string> ListSubProjects { get; set; }
        ObservableCollection<string> ListSow { get; set; }
        ObservableCollection<TimeEntryDetails> ListTimeEntry { get; set; }

        IRelayCommand CommandEditTimeEntry { get; set; }
    }
}
