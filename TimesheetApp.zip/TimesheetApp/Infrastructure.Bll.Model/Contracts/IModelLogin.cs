﻿using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
    public interface IModelLogin
    {
        string Username { get; set; }
        string Password { get; set; }

        IRelayCommand CommandLogin { get; set; }
    }
}
