﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
    public interface IModelNavigation
    {
        string ViewTimesheetGridIsVisible { get; set; }
        IRelayCommand CommandListOfTimeSheet { get; set; }
    }
}
