﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Bll.Model.Services;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
   public interface IUserDetailsPage
    {
        string AssignedTeam { get; set; }
        List<Project> ProjectNames { get; set; }
        string Products { get; set; }
        string ProjectCode { get; set; }
        string DisplayLocation { get; set; }
        string JiraRef { get; set; }
        string TaskDetails { get; set; }
        string ProjectTeam { get; set; }
        string ComapnyName { get; set; }
        string Sow { get; set; }
        DateTime? Date { get; set; }
       // DateTime Hours { get; set; }
    }
}
