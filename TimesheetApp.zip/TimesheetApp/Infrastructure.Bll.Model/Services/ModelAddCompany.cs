﻿using System;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Bll.Model.Contracts;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Entity.Services;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    public class ModelAddCompany : ViewModelBase, IModelAddCompany
    {
    }
}
