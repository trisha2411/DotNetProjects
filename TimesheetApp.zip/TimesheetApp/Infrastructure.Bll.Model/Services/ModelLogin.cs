﻿using System;
using MyApp.Infrastructure.Bll.Model.Contracts;
using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    public class ModelLogin : IModelLogin
    {
        public string Username
        { get; set; }

        public string Password
        { get; set; }

        public IRelayCommand CommandLogin
        { get; set;}
    }
}
