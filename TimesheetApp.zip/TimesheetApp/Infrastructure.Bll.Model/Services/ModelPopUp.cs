﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Bll.Model.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    public class ModelPopUp : IModelPopUp
    {
    }
}
