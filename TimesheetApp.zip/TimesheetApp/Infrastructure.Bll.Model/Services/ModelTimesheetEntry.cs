﻿using System;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Bll.Model.Contracts;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Entity.Services;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    public class ModelTimesheetEntry : ViewModelBase, IModelTimesheetEntry
    {
        public DateTime WorkDate { get; set; }
        public string WorkHours { get; set; }
        public string Name { get; set; }
        public string AssignedTeam { get; set; }
        public string CompanyCode { get; set; }
        public string SowCode { get; set; }
        public string ProjectCode { get; set; }
        public string ProjectName { get; set; }
        public string SubProjectCode { get; set; }
        public string Location { get; set; }
        public string JiraRef { get; set; }
        public string TaskDetails { get; set; }

        public IRelayCommand CommandAddTimeEntry
        { get; set; }

        private ObservableCollection<string> listProjects = new ObservableCollection<string>();
        public ObservableCollection<string> ListProjects
        {
            get { return listProjects; }
            set
            {
                listProjects = value;
                OnPropertyChanged("ListProjects");
            }
        }

        private ObservableCollection<string> listSubProjects = new ObservableCollection<string>();
        public ObservableCollection<string> ListSubProjects
        {
            get { return listSubProjects; }
            set
            {
                listSubProjects = value;
                OnPropertyChanged("ListSubProjects");
            }
        }

        private ObservableCollection<string> listAssignedTeams = new ObservableCollection<string>();
        public ObservableCollection<string> ListAssignedTeams
        {
            get { return listAssignedTeams; }
            set
            {
                listAssignedTeams = value;
                OnPropertyChanged("ListAssignedTeams");
            }
        }

        private ObservableCollection<string> listLocations = new ObservableCollection<string>();
        public ObservableCollection<string> ListLocations
        {
            get { return listLocations; }
            set
            {
                listLocations = value;
                OnPropertyChanged("ListLocations");
            }
        }

        private ObservableCollection<string> listCompanies = new ObservableCollection<string>();
        public ObservableCollection<string> ListCompanies
        {
            get { return listCompanies; }
            set
            {
                listCompanies = value;
                OnPropertyChanged("ListCompanies");
            }
        }

        private ObservableCollection<string> listSow = new ObservableCollection<string>();
        public ObservableCollection<string> ListSow
        {
            get { return listSow; }
            set
            {
                listSow = value;
                OnPropertyChanged("ListSow");
            }
        }

        private ObservableCollection<TimeEntryDetails> listTimeEntry = null;
        public ObservableCollection<TimeEntryDetails> ListTimeEntry
        {
            get { return listTimeEntry; }
            set
            {
                listTimeEntry = value;
                OnPropertyChanged("ListTimeEntry");
            }
        }
    }
}
