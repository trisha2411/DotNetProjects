﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Bll.Model.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    class UserDetailsPage : IUserDetailsPage
    {
        private string assignedTeam;
        public string AssignedTeam
        {
            get { return assignedTeam; }
            set { assignedTeam = value; }
        }

        private List<Project>projectNames;
        public List<Project> ProjectNames
        {
            get { return projectNames; }
            set { projectNames = value; }
        }

        private string products;
        public string Products
        {
            get { return products; }
            set { products = value; }
        }

        private string projectCode;
        public string ProjectCode
        {
            get { return projectCode; }
            set { projectCode = value; }
        }

        private string displayLocation;
        public string DisplayLocation
        {
            get { return displayLocation; }
            set { displayLocation = value; }
        }

        private string jiraRef;
        public string JiraRef
        {
            get { return jiraRef; }
            set { jiraRef = value; }
        }

        private string taskDetails;
        public string TaskDetails
        {
            get { return taskDetails; }
            set { taskDetails = value; }
        }

        private string projectTeam;
        public string ProjectTeam
        {
            get { return projectTeam; }
            set { projectTeam = value; }
        }

        private string comapnyName;
        public string ComapnyName
        {
            get { return comapnyName; }
            set { comapnyName = value; }
        }

        private string sow;
        public string Sow
        {
            get { return sow; }
            set { sow = value; }
        }

        private DateTime? date;
        public DateTime? Date
        {
            get { return date; }
            set { date = value; }
        }
    }

    public class Project
    {
        private string _projectId;
        public string ProjectId
        {
            get { return _projectId; }
            set { _projectId = value; }

        }
        private string _projectName;
        public string ProjectName
        {
            get { return _projectName; }
            set { _projectName = value; }
        }

        private string _projectComboDetails;
        public string ProjectComboDetails
        {
            get { return _projectComboDetails; }
            set { _projectComboDetails = value; }
        }
        
    }
}
