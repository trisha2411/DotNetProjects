﻿using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Interaction.Contracts;

namespace MyApp.Infrastructure.Bll.ViewModel.Contracts
{
    public interface IVMMain : IViewModelPresenter<IViewMain, ModelMain>
    {
    }
}
