﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Interaction.Contracts;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Common.Contracts;

namespace MyApp.Infrastructure.Bll.ViewModel.Contracts
{
    public interface IVMPopUp : IViewModelPresenter<IViewMain, ModelMain>
    {
    }
}
