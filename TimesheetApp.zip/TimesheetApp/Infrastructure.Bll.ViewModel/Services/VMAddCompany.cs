﻿using System;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Entity.Services;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Unity.Services;
using System.Windows;
using Microsoft.Practices.Unity;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMAddCompany : ViewModelPresenter<IViewAddCompany, ModelAddCompany>, IVMAddCompany
    {
        private void InitializeObjects()
        {}
    }
    public partial class VMAddCompany : ViewModelPresenter<IViewAddCompany, ModelAddCompany>, IVMAddCompany
    {
        #region Constructors

        public VMAddCompany(ViewContext<IViewAddCompany> context)
            : base(context)
        { InitializeObjects(); }

        #endregion
    }
}
