﻿using Microsoft.Practices.Unity;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Common.Services;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Unity.Services;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMMain : ViewModelPresenter<IViewMain, ModelMain>, IVMMain
    {
        #region private methods

        private void InitializeObjects()
        {
            try
            {
                IVMTimesheetEntry viewTimesheetEntry = ContainerService.Instance.Container.Resolve<IVMTimesheetEntry>();
                var childView = (System.Windows.Controls.UserControl)viewTimesheetEntry.View;
                var mainDisplayGrid = ((System.Windows.Controls.Grid)GlobalObjects.Instance.MainDisplayGrid);
                mainDisplayGrid.Children.Add(childView);
            }
            catch { }
        }

        #endregion
    }
    public partial class VMMain : ViewModelPresenter<IViewMain, ModelMain>, IVMMain
    {
        #region Constructors
        
        public VMMain(ViewContext<IViewMain> context)
            : base(context)
        { InitializeObjects(); }
    
        #endregion
    }
}
