﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMNavigation : ViewModelPresenter<IViewNavigation, ModelNavigation>, IVMNavigation
    {
        #region private methods

        private void InitializeObjects()
        {
           // ViewModel.ViewTimesheetGridIsVisible = "Collapsed";
            try
            {
                if (ViewModel.CommandListOfTimeSheet == null)
                { ViewModel.CommandListOfTimeSheet = new RelayCommand(ExecuteListOfTimeSheet) as IRelayCommand; }
                //if (ViewModel.CommandEditTimeEntry == null)
                //{ ViewModel.CommandEditTimeEntry = new RelayCommand(ExecuteEditTimeEntry) as IRelayCommand; }
                //if (ViewModel.CommandSaveTimeEntry == null)
                //{ ViewModel.CommandSaveTimeEntry = new RelayCommand(ExecuteSaveTimeEntry) as IRelayCommand; }
                //ViewModel.WorkDate = DateTime.Now;
                //LoadDropDownLists();
            }
            catch { }
        }

        private void ExecuteListOfTimeSheet()
        {
           // ViewModel.ViewTimesheetGridIsVisible = "Visible";
            //try
            //{
            //    if (ViewModel.ListTimeEntry == null)
            //    { ViewModel.ListTimeEntry = new ObservableCollection<TimeEntryDetails>(); }
            //    ViewModel.ListTimeEntry.Add(SetCurrentTimeDetailsEntry());
            //}
            //catch { }
        }

        #endregion
    }
     public partial class VMNavigation : ViewModelPresenter<IViewNavigation, ModelNavigation>, IVMNavigation
          {
        #region Constructors
        
        public VMNavigation(ViewContext<IViewNavigation> context)
            : base(context)
        { InitializeObjects(); }
    
        #endregion
    }
}
