﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Unity.Services;
using MyApp.Infrastructure.Common.Services;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMPopUp : ViewModelPresenter<IViewPopUp, ModelPopUp>, IVMPopUp
    {
        #region private methods

        private void InitializeObjects()
        {
            try
            {
                IVMEdit viewUCEditControl = ContainerService.Instance.Container.Resolve<IVMEdit>();
                var childEditView = (System.Windows.Controls.UserControl)viewUCEditControl.View;
                var editDisplayGrid = ((System.Windows.Controls.Grid)GlobalObjects.Instance.EditDisplayGrid);
                editDisplayGrid.Children.Add(childEditView);
            }

            catch { }
        }

        #endregion
    }
    public partial class VMPopUp : ViewModelPresenter<IViewPopUp, ModelPopUp>, IVMPopUp
    {
        #region Constructors

        public VMPopUp(ViewContext<IViewPopUp> context)
            : base(context)
        { InitializeObjects(); }

        #endregion
    }
}
