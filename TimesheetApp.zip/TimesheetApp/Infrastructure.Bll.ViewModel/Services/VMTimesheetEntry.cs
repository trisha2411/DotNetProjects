﻿using System;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Entity.Services;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Unity.Services;
using System.Windows;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMTimesheetEntry : ViewModelPresenter<IViewTimesheetEntry, ModelTimesheetEntry>, IVMTimesheetEntry
    {
        #region private methods

        private void InitializeObjects()
        {
            try
            {
                if (ViewModel.CommandAddTimeEntry == null)
                { ViewModel.CommandAddTimeEntry = new RelayCommand(ExecuteAddTimeEntry) as IRelayCommand; }
                ViewModel.WorkDate = DateTime.Now;
                LoadDropDownLists();
                if (ViewModel.CommandEditTimeEntry == null)
                { ViewModel.CommandEditTimeEntry = new RelayCommand(ExecuteEditTimeEntry) as IRelayCommand; }
               // ViewModel.WorkDate = DateTime.Now;
               // LoadDropDownLists();
                if (ViewModel.CommandSaveTimeEntry == null)
                { ViewModel.CommandSaveTimeEntry = new RelayCommand(ExecuteSaveTimeEntry) as IRelayCommand; }
               // ViewModel.WorkDate = DateTime.Now;
               // LoadDropDownLists();
            }
            catch { }

        }

        private void ExecuteAddTimeEntry()
        {
            try
            {
                if (ViewModel.ListTimeEntry == null)
                { ViewModel.ListTimeEntry = new ObservableCollection<TimeEntryDetails>(); }
                ViewModel.ListTimeEntry.Add(SetCurrentTimeDetailsEntry());
            }
            catch { }
        }
        private void ExecuteEditTimeEntry()
        {
            try
            {
                IVMMain viewMain = ContainerService.Instance.Container.Resolve<IVMMain>();
                ((Window)(viewMain.View)).Show();
            }
            catch { }
        }
        private void ExecuteSaveTimeEntry()
        {
            try
            {
                if (ViewModel.ListTimeEntry == null)
                { ViewModel.ListTimeEntry = new ObservableCollection<TimeEntryDetails>(); }
                ViewModel.ListTimeEntry.Add(SetCurrentTimeDetailsEntry());
            }
            catch { }
        }

        private TimeEntryDetails SetCurrentTimeDetailsEntry()
        {
            TimeEntryDetails timeDetailsEntry = null;
            try
            {
                timeDetailsEntry = new TimeEntryDetails
                {
                    AssignedTeam = ViewModel.AssignedTeam,
                    CompanyCode = ViewModel.CompanyCode,
                    JiraRef = ViewModel.JiraRef,
                    Location = ViewModel.Location,
                    Name = "Test User",
                    ProjectCode = ViewModel.ProjectCode,
                    ProjectName = ViewModel.ProjectName,
                    SowCode = ViewModel.SowCode,
                    SubProjectCode = ViewModel.SubProjectCode,
                    TaskDetails = ViewModel.TaskDetails,
                    WorkDate = ViewModel.WorkDate.ToShortDateString(),
                    WorkHours = ViewModel.WorkHours
                };
            }
            catch { timeDetailsEntry = new TimeEntryDetails(); }
            return timeDetailsEntry;
        }

        private void LoadDropDownLists()
        {
            try
            {
                LoadListAssignedTeams();
                LoadListCompanies();
                LoadListLocations();
                LoadListProject();
                LoadListSubProject();
                LoadListSow();
            }
            catch { }
        }

        private void LoadListAssignedTeams()
        {
            try
            {
                if (ViewModel.ListAssignedTeams != null && ViewModel.ListAssignedTeams.Count == 0)
                {
                    ViewModel.ListAssignedTeams.Add("OmnOffshore # Oman-Offshore");
                    ViewModel.ListAssignedTeams.Add("OmnOnsite # Oman-Onsite");
                }
            }
            catch { }
        }

        private void LoadListCompanies()
        {
            try
            {
                if (ViewModel.ListCompanies != null && ViewModel.ListCompanies.Count == 0)
                {
                    ViewModel.ListCompanies.Add("IGT # Interglobe Technologies Pvt Ltd");
                    ViewModel.ListCompanies.Add("IGTSOL # Interglobe Solutions Pvt Ltd");
                }
            }
            catch { }
        }

        private void LoadListSow()
        {
            try
            {
                if (ViewModel.ListSow != null && ViewModel.ListSow.Count == 0)
                {
                    ViewModel.ListSow.Add("2016_28 # 2016_28");
                    ViewModel.ListSow.Add("2017_28 # 2017_28");
                }
            }
            catch { }
        }

        private void LoadListLocations()
        {
            try
            {
                if (ViewModel.ListLocations != null && ViewModel.ListLocations.Count == 0)
                {
                    ViewModel.ListLocations.Add("IN # India");
                    ViewModel.ListLocations.Add("OMN # Oman");
                }
            }
            catch { }
        }

        private void LoadListProject()
        {
            try
            {
                if (ViewModel.ListProjects != null && ViewModel.ListProjects.Count == 0)
                {
                    ViewModel.ListProjects.Add("DO228.02 # SITA GSL OMAN");
                    ViewModel.ListProjects.Add("D0228.03 # SITA GSL Saudi");
                }
            }
            catch { }
        }

        private void LoadListSubProject()
        {
            try
            {
                if (ViewModel.ListSubProjects != null && ViewModel.ListSubProjects.Count == 0)
                {
                    ViewModel.ListSubProjects.Add("EE # EntryExit");
                    ViewModel.ListSubProjects.Add("EVisa # EVisa");
                    ViewModel.ListSubProjects.Add("VIS # Visitor Information System");
                }
            }
            catch { }
        }
        #endregion
    }

    public partial class VMTimesheetEntry : ViewModelPresenter<IViewTimesheetEntry, ModelTimesheetEntry>, IVMTimesheetEntry
    {
        #region Constructors

        public VMTimesheetEntry(ViewContext<IViewTimesheetEntry> context)
            : base(context)
        { InitializeObjects(); }

        #endregion


    }
}
