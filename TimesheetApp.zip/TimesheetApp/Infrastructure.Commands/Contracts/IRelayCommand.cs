﻿using System.Windows.Input;

namespace MyApp.Infrastructure.Commands.Contracts
{
    public interface IRelayCommand : ICommand
    {
    }
}
