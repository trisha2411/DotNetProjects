﻿using System.ComponentModel;

namespace MyApp.Infrastructure.Commands.Contracts
{
    public interface IViewModelBase : INotifyPropertyChanged
    {
    }
}
