﻿
namespace MyApp.Infrastructure.Common.Contracts
{
    public interface IMessageInfo 
    {
        void ShowMessage(string message);
    }
}
