﻿namespace MyApp.Infrastructure.Common.Services
{
    public class GlobalObjects
    {
        #region Constructors

        private GlobalObjects()
        { }

        #endregion

        #region public properties

        private static GlobalObjects instance = null;
        public static GlobalObjects Instance
        {
            get
            {
                if (instance == null)
                { instance = new GlobalObjects(); }
                return instance;
            }
        }

        private object mainDisplayGrid;
        public object MainDisplayGrid
        {
            get { return mainDisplayGrid; }
            set { mainDisplayGrid = value; }
        }

        private object editDisplayGrid;
         public object EditDisplayGrid
        {
            get { return editDisplayGrid; }
            set { editDisplayGrid = value; }
        }
       
        #endregion

    }
}
