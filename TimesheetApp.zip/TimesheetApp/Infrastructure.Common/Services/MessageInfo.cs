﻿using System.Windows.Forms;
using MyApp.Infrastructure.Common.Contracts;

namespace MyApp.Infrastructure.Common.Services
{
    public class MessageInfo : IMessageInfo
    {
        public void ShowMessage(string message)
        {
            MessageBox.Show(message);
        }
    }
}
