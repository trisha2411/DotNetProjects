﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyApp.Infrastructure.DBEntity.Contracts
{
    public interface IDBQueries
    {
        string GetSelectDataQuery(string tableName, string fields, string joinCondition, string whereCondition);
    }
}
