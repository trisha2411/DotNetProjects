﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyApp.Infrastructure.DBEntity.Services
{
    public class DBQueriesConstants
    {
        public const string tableName = "<table>",
            fields = "<fields>",
            joinCondition = "<joinCondition>",
            whereCondition = "<whereCondition>",
            fieldWithValues = "<fieldsWithValue>",
            fieldsValue = "<fieldsValue>";
    }
    public class DBTables
    {
        public const string Login = "Login";
    }

    public class Login
    {
        public const string userName = "UserId",
            password = "Password";        
    }
}
