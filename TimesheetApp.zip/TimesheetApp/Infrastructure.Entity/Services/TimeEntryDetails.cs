﻿
namespace MyApp.Infrastructure.Entity.Services
{
    public class TimeEntryDetails
    {
        public string WorkDate { get; set; }
        public string WorkHours { get; set; }
        public string Name { get; set; }
        public string AssignedTeam { get; set; }
        public string CompanyCode { get; set; }
        public string SowCode { get; set; }        
        public string ProjectCode { get; set; }
        public string ProjectName { get; set; }
        public string SubProjectCode { get; set; }
        public string Location { get; set; }
        public string JiraRef { get; set; }
        public string TaskDetails { get; set; }
    }
}
