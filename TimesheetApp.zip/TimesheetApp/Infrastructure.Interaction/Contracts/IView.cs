﻿
namespace MyApp.Infrastructure.Interaction.Contracts
{
    public interface IView
    {
        object DataContext { get; set; }
    }
}
