﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyApp.Infrastructure.Interaction.Contracts
{
    public interface IViewModelPresenter<TView>
    {
        TView View { get; }
    }

    public interface IViewModelPresenter<TView, TViewModel> : IViewModelPresenter<TView>
    {
        TViewModel ViewModel { get; }
    }
}
