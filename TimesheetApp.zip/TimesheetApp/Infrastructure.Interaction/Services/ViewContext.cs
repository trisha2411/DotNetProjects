﻿using Microsoft.Practices.Unity;
namespace MyApp.Infrastructure.Interaction.Services
{
    public class ViewContext<TView>
    {
        [Dependency]
        public TView View { get; set; }
    }
}
