﻿using System;
using MyApp.Infrastructure.Interaction.Contracts;
using MyApp.Infrastructure.Commands.Services;

namespace MyApp.Infrastructure.Interaction.Services
{
    public abstract class ViewModelPresenter<TView, TViewModel> : ViewModelBase, IViewModelPresenter<TView, TViewModel>, IDisposable
        where TViewModel : new()
        where TView : IView
    {
        public TViewModel ViewModel
        {
            get;
            private set;
        }

        public TView View
        {
            get;
            private set;
        }

        public ViewModelPresenter(ViewContext<TView> viewContext)
        {
            this.View = viewContext.View;
            this.ViewModel = new TViewModel();
            this.View.DataContext = this.ViewModel;
        }

        public ViewModelPresenter(ViewContext<TView> viewContext, object dataContext)
        {
            this.View = viewContext.View;
            this.ViewModel = (TViewModel)dataContext;
            this.View.DataContext = this.ViewModel;
        }

        public void Dispose()
        {
         
        }
    }
}
