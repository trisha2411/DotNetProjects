﻿namespace MyApp.Infrastructure.SharedDll.Contracts
{
    public interface IUnityContainer : Microsoft.Practices.Unity.IUnityContainer
    { }
}
