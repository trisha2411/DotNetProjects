﻿using MyApp.Infrastructure.Unity.Contracts;
namespace MyApp.Infrastructure.Unity.Services
{
    public class Container : IContainer
    {
        
        private Container() { }

        private static IContainer containerInstance = null;
        public static IContainer ContainerInstance
        {
            get
            {
                if (containerInstance == null)
                { containerInstance = new Container(); }
                return containerInstance;
            }
        }
        
    }
}
