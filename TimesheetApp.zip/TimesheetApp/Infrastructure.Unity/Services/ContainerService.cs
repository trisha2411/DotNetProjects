﻿using Microsoft.Practices.Unity;

namespace MyApp.Infrastructure.Unity.Services
{
    public class ContainerService
    {
        private ContainerService()
        { }

        private static ContainerService instance = null;
        public static ContainerService Instance
        {
            get
            {
                if (instance == null)
                { instance = new ContainerService(); }
                return instance;
            }
        }

        private IUnityContainer container = null;
        public IUnityContainer Container
        {
            get
            {
                if (container == null)
                { container = new UnityContainer(); }
                return container;
            }
        }
    }
}
