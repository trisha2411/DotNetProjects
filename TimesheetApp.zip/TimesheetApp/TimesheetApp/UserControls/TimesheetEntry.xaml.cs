﻿using System.Windows.Controls;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Bll.Model.Services;
using Microsoft.Practices.Unity;

namespace MyApp.UI.Timesheet.UserControls
{
    /// <summary>
    /// Interaction logic for TimesheetEntry.xaml
    /// </summary>
    public partial class TimesheetEntry : UserControl, IViewTimesheetEntry
    {
        public TimesheetEntry()
        {
            InitializeComponent();
        }

        //[Dependency]
        //public ModelTimesheetEntry ViewModel
        //{
        //    get { return DataContext as ModelTimesheetEntry; }
        //    set { DataContext = value; }
        //}
    }
}
