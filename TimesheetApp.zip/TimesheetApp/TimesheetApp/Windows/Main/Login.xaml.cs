﻿using System.Windows;
using MyApp.Infrastructure.Common.Contracts;

namespace MyApp.UI.Timesheet.Windows.Main
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window, IViewLogin
    {
        public Login()
        {
            InitializeComponent();
            Style = (Style)FindResource(typeof(Window));            
        }
    }
}
