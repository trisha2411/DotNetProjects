﻿using System.Windows;
using System.Windows.Forms;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Common.Services;

namespace MyApp.UI.Timesheet.Windows.Main
{
    /// <summary>
    /// Interaction logic for Mainwin.xaml
    /// </summary>
    public partial class Mainwin : Window, IViewMain
    {
        public Mainwin()
        {
            InitializeComponent();
            GlobalObjects.Instance.MainDisplayGrid = gridContent;
            this.WindowState = (WindowState)FormWindowState.Maximized;
        }
    }
}
