﻿using System;
using MyApp.DAL.Contracts;

namespace MyApp.DAL.Services
{
    public class SqlDataService : ISqlDataService
    {
        public string GetColumnsForTable(string[] columnList)
        {
            string columnsName = string.Empty;
            try
            {
                foreach (string column in columnList)
                { columnsName = columnsName + ", " + column; }
                columnsName = columnsName.TrimStart(',').TrimEnd(',');
            }
            catch { }
            return columnsName;
        }
    }
}
