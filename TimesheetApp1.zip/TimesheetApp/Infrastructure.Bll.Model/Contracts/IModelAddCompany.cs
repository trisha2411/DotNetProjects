﻿using System;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Entity.Services;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
    public interface IModelAddCompany
    {
    }
}
