﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Commands.Contracts;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Entity.Services;

namespace MyApp.Infrastructure.Bll.Model.Contracts
{
    public interface IModelTimeSheetLog
    {
        DateTime StartTimeWorkDate { get; set; }
        DateTime EndTimeWorkDate { get; set; }
        IRelayCommand CommandWatchTimeSheetEntry { get; set; }
        ObservableCollection<TimeEntryDetails> ListTimeEntry { get; set; }
    }
}
