﻿
namespace MyApp.Infrastructure.Bll.Model.Contracts
{
    public interface IUser
    {
        string Username { get; set; }
        string Role { get; set; }
    }
}
