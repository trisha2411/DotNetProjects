﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Bll.Model.Contracts;
using MyApp.Infrastructure.Commands.Contracts;
using System.Collections.ObjectModel;
using MyApp.Infrastructure.Entity.Services;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    public class ModelEdit: ViewModelBase, IModelEdit
    {
        public DateTime EditWorkDate { get; set; }
        public string EditWorkHours { get; set; }
        public string EditName { get; set; }
        public string EditAssignedTeam { get; set; }
        public string EditCompanyCode { get; set; }
        public string EditSowCode { get; set; }
        public string EditProjectCode { get; set; }
        public string EditProjectName { get; set; }
        public string EditSubProjectCode { get; set; }
        public string EditLocation { get; set; }
        public string EditJiraRef { get; set; }
        public string EditTaskDetails { get; set; }

        public IRelayCommand CommandEditTimeEntry
        { get; set; }

        private ObservableCollection<string> listProjects = new ObservableCollection<string>();
        public ObservableCollection<string> ListProjects
        {
            get { return listProjects; }
            set
            {
                listProjects = value;
                OnPropertyChanged("ListProjects");
            }
        }

        private ObservableCollection<string> listSubProjects = new ObservableCollection<string>();
        public ObservableCollection<string> ListSubProjects
        {
            get { return listSubProjects; }
            set
            {
                listSubProjects = value;
                OnPropertyChanged("ListSubProjects");
            }
        }

        private ObservableCollection<string> listAssignedTeams = new ObservableCollection<string>();
        public ObservableCollection<string> ListAssignedTeams
        {
            get { return listAssignedTeams; }
            set
            {
                listAssignedTeams = value;
                OnPropertyChanged("ListAssignedTeams");
            }
        }

        private ObservableCollection<string> listLocations = new ObservableCollection<string>();
        public ObservableCollection<string> ListLocations
        {
            get { return listLocations; }
            set
            {
                listLocations = value;
                OnPropertyChanged("ListLocations");
            }
        }

        private ObservableCollection<string> listCompanies = new ObservableCollection<string>();
        public ObservableCollection<string> ListCompanies
        {
            get { return listCompanies; }
            set
            {
                listCompanies = value;
                OnPropertyChanged("ListCompanies");
            }
        }

        private ObservableCollection<string> listSow = new ObservableCollection<string>();
        public ObservableCollection<string> ListSow
        {
            get { return listSow; }
            set
            {
                listSow = value;
                OnPropertyChanged("ListSow");
            }
        }

        private ObservableCollection<TimeEntryDetails> listTimeEntry = null;
        public ObservableCollection<TimeEntryDetails> ListTimeEntry
        {
            get { return listTimeEntry; }
            set
            {
                listTimeEntry = value;
                OnPropertyChanged("ListTimeEntry");
            }
        }
    }
}
