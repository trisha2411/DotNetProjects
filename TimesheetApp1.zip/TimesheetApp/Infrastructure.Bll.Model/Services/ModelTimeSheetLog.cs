﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Bll.Model.Contracts;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Entity.Services;
using System.Collections.ObjectModel;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    public class ModelTimeSheetLog : ViewModelBase, IModelTimeSheetLog
    {
        public DateTime StartTimeWorkDate { get; set; }
        public DateTime EndTimeWorkDate { get; set; }
        public IRelayCommand CommandWatchTimeSheetEntry { get; set; }
        public ObservableCollection<TimeEntryDetails> ListTimeEntry { get; set; }
    }
}
