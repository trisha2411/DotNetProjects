﻿using MyApp.Infrastructure.Bll.Model.Contracts;

namespace MyApp.Infrastructure.Bll.Model.Services
{
    public class User : IUser
    {
        public string Username
        { get; set; }

        public string Role
        { get; set; }

    }
}
