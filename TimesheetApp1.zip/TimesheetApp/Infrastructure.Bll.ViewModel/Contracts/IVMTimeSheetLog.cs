﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Interaction.Contracts;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Bll.Model.Services;

namespace MyApp.Infrastructure.Bll.ViewModel.Contracts
{
    public interface IVMTimeSheetLog : IViewModelPresenter<IViewTimeSheetLog, ModelTimeSheetLog>
    {
    }
}
