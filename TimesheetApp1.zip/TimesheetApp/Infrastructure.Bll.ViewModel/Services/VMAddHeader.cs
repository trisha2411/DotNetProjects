﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Interaction.Services;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
   public class VMAddHeader : ViewModelPresenter<IViewAddHeader,AddHeader>, IVMAddHeader
    {
        public VMAddHeader(ViewContext<IViewAddHeader> context)
            : base(context)
        {
           
        }
    }
}
