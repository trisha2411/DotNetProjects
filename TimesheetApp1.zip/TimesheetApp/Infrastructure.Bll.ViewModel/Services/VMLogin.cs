﻿using System.Windows;
using Microsoft.Practices.Unity;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Unity.Services;
using MyApp.Infrastructure.DBEntity.Contracts;
using System.Configuration;
using MyApp.Infrastructure.DBEntity.Services;
using MyApp.DAL.Contracts;
using System.Data;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMLogin : ViewModelPresenter<IViewLogin, ModelLogin>, IVMLogin
    {
        #region private methods

        private void InitializeObjects()
        {
            if (ViewModel.CommandLogin == null)
            { ViewModel.CommandLogin = new RelayCommand(LoginExecute) as IRelayCommand; }
        }

        private bool IsFormValid()
        {
            bool isValid = false;
            if (string.IsNullOrEmpty(ViewModel.Username) ||
                string.IsNullOrEmpty(ViewModel.Password)
                )
            { isValid = false; }
            else
            { isValid = true; }
            return isValid;
        }


        private void LoginExecute()
        {
            try
            {
               
                {

                    
                    ISqlDataService sqlDataService = ContainerService.Instance.Container.Resolve<ISqlDataService>();
                    string fieldsColumnNames = sqlDataService.GetColumnsForTable(new string[] { DBEntity.Services.userInfo.userName,
                    DBEntity.Services.userInfo.password});

                    string whereCondition= "where username='"+ViewModel.Username+"' and password= '"+ViewModel.Password+"'";

                    IDBQueries dbQuery = ContainerService.Instance.Container.Resolve<IDBQueries>();
                    string query = dbQuery.GetSelectDataQuery(DBTables.userInfo,fieldsColumnNames, string.Empty,whereCondition);
                   
                    string connString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString.ToString();
                    IDataHelper dtHelper = ContainerService.Instance.Container.Resolve<IDataHelper>();
                    dtHelper.DBConnectionString = connString;
                    DataTable data = dtHelper.GetDataTable(query);
                    if (data.Rows.Count > 0)
                    {
                        IVMMain viewMain = ContainerService.Instance.Container.Resolve<IVMMain>();                    
                        ((Window)(viewMain.View)).Show();
                        ((Window)this.View).Hide();

                    }
                    else
                    {
                        MessageBox.Show("Username or Password is incorrect");

                    }

                }
            }
            catch 
            { }
        }

        #endregion
    }
    public partial class VMLogin : ViewModelPresenter<IViewLogin, ModelLogin>, IVMLogin
    {
        #region Constructors

        public VMLogin(ViewContext<IViewLogin> context)
            : base(context)
        { InitializeObjects(); }

        #endregion
    }
}
