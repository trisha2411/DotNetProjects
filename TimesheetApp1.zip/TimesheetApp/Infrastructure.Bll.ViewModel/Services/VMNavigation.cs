﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Commands.Contracts;
using MyApp.Infrastructure.Unity.Services;
using MyApp.Infrastructure.Common.Services;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMNavigation : ViewModelPresenter<IViewNavigation, ModelNavigation>, IVMNavigation
    {
        #region private methods

        private void InitializeObjects()
        {
          
            try
            {
                if (ViewModel.CommandListOfTimeSheet == null)
                { ViewModel.CommandListOfTimeSheet = new RelayCommand(ExecuteListOfTimeSheet) as IRelayCommand; }
               
            }
            catch { }
        }

        private void ExecuteListOfTimeSheet()
        {
            try
            {
                IVMTimeSheetLog viewTimeSheetLogEntry = ContainerService.Instance.Container.Resolve<IVMTimeSheetLog>();
                var childTimeSheetLogView = (System.Windows.Controls.UserControl)viewTimeSheetLogEntry.View;
                var mainDisplayGrid = ((System.Windows.Controls.Grid)GlobalObjects.Instance.MainDisplayGrid);
                mainDisplayGrid.Children.Clear();
                mainDisplayGrid.Children.Add(childTimeSheetLogView);
            }
            catch { }
        }

        #endregion
    }
     public partial class VMNavigation : ViewModelPresenter<IViewNavigation, ModelNavigation>, IVMNavigation
          {
        #region Constructors
        
        public VMNavigation(ViewContext<IViewNavigation> context)
            : base(context)
        { InitializeObjects(); }
    
        #endregion
    }
}
