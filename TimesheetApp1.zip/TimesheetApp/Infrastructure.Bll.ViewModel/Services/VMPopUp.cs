﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Unity.Services;
using MyApp.Infrastructure.Common.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Interaction.Services;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMPopUp : ViewModelPresenter<IViewPopUp, ModelPopUp>, IVMPopUp
    {
        #region private methods

        private void InitializeObjects()
        {
            try
            {
                IVMEdit viewUcEditControl = ContainerService.Instance.Container.Resolve<IVMEdit>();
                var childEditView = (System.Windows.Controls.UserControl)viewUcEditControl.View;
                var editDisplayGrid = ((System.Windows.Controls.Grid)GlobalObjects.Instance.EditDisplayGrid);
                editDisplayGrid.Children.Add(childEditView);
            }
            catch { }
        }

        #endregion
    }
     public partial class VMPopUp : ViewModelPresenter<IViewPopUp, ModelPopUp>, IVMPopUp
      {
        #region Constructors
        
        public VMPopUp(ViewContext<IViewPopUp> context)
            : base(context)
        { InitializeObjects(); }
    
        #endregion
    }
}
