﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyApp.Infrastructure.Interaction.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.Bll.Model.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Commands.Services;
using MyApp.Infrastructure.Commands.Contracts;

namespace MyApp.Infrastructure.Bll.ViewModel.Services
{
    public partial class VMTimeSheetLog : ViewModelPresenter<IViewTimeSheetLog, ModelTimeSheetLog>, IVMTimeSheetLog
    {
        #region private methods

        private void InitializeObjects()
        {
            try
            {
                if (ViewModel.CommandWatchTimeSheetEntry == null)
                { ViewModel.CommandWatchTimeSheetEntry = new RelayCommand(ExecuteWatchTimeSheetEntry) as IRelayCommand; }
                
            }
            catch { }
        }

        private void ExecuteWatchTimeSheetEntry()
        {
            //try
            //{
            //    if (ViewModel.ListTimeEntry == null)
            //    { ViewModel.ListTimeEntry = new ObservableCollection<TimeEntryDetails>(); }
            //    ViewModel.ListTimeEntry.Add(SetCurrentTimeDetailsEntry());
            //}
            //catch { }
        }

        //private void ExecuteEditTimeEntry()
        //{
        //    try
        //    {
        //        IVMPopUp viewMain = ContainerService.Instance.Container.Resolve<IVMPopUp>();
        //        ((Window)(viewMain.View)).Show();

        //        ((Window)this.View).Hide();

        //    }
        //    catch { }
        //}

        //private void SaveDataToDatabase()
        //{

        //}


        //private void ExecuteSaveTimeEntry()
        //{
        //    //try
        //    //{
        //    //    if (ViewModel.ListTimeEntry == null)
        //    //    { ViewModel.ListTimeEntry = new ObservableCollection<TimeEntryDetails>(); }
        //    //    ViewModel.ListTimeEntry.Add(SetCurrentTimeDetailsEntry());
        //    //}
        //    //catch { }
        //}

        //private TimeEntryDetails SetCurrentTimeDetailsEntry()
        //{
        //    TimeEntryDetails timeDetailsEntry = null;
        //    try
        //    {
        //        timeDetailsEntry = new TimeEntryDetails
        //        {
        //            AssignedTeam = ViewModel.AssignedTeam,
        //            CompanyCode = ViewModel.CompanyCode,
        //            JiraRef = ViewModel.JiraRef,
        //            Location = ViewModel.Location,
        //            Name = "Test User",
        //            ProjectCode = ViewModel.ProjectCode,
        //            ProjectName = ViewModel.ProjectName,
        //            SowCode = ViewModel.SowCode,
        //            SubProjectCode = ViewModel.SubProjectCode,
        //            TaskDetails = ViewModel.TaskDetails,
        //            WorkDate = ViewModel.WorkDate.ToShortDateString(),
        //            WorkHours = ViewModel.WorkHours
        //        };
        //    }
        //    catch { timeDetailsEntry = new TimeEntryDetails(); }
        //    return timeDetailsEntry;
        //}

        //private void LoadDropDownLists()
        //{
        //    try
        //    {
        //        LoadListAssignedTeams();
        //        LoadListCompanies();
        //        LoadListLocations();
        //        LoadListProject();
        //        LoadListSubProject();
        //        LoadListSow();
        //    }
        //    catch { }
        //}

        //private void LoadListAssignedTeams()
        //{
        //    try
        //    {
        //        if (ViewModel.ListAssignedTeams != null && ViewModel.ListAssignedTeams.Count == 0)
        //        {
        //            //ViewModel.ListAssignedTeams.Add("OmnOffshore # Oman-Offshore");
        //            //ViewModel.ListAssignedTeams.Add("OmnOnsite # Oman-Onsite");
        //            ISqlDataService sqlDataService = ContainerService.Instance.Container.Resolve<ISqlDataService>();
        //            string fieldsColumnNames = sqlDataService.GetColumnsForTable(new string[] { DBEntity.Services.TeamInfo.ID,
        //            DBEntity.Services.TeamInfo.TeamCode,
        //            DBEntity.Services.TeamInfo.TeamName
        //            });
        //            string getTableName = DBTables.Team;
        //            DataTable getProjectList = CommonQueryForAll(getTableName, fieldsColumnNames);
        //            foreach (DataRow dataRow in getProjectList.Rows)
        //            {
        //                string outputCode = dataRow[DBEntity.Services.TeamInfo.TeamCode].ToString() + " # " + dataRow[DBEntity.Services.TeamInfo.TeamName].ToString();
        //                ViewModel.ListAssignedTeams.Add(outputCode);
        //            }

        //        }
        //    }
        //    catch { }
        //}

        //private void LoadListCompanies()
        //{
        //    try
        //    {
        //        if (ViewModel.ListCompanies != null && ViewModel.ListCompanies.Count == 0)
        //        {
        //            ISqlDataService sqlDataService = ContainerService.Instance.Container.Resolve<ISqlDataService>();
        //            string fieldsColumnNames = sqlDataService.GetColumnsForTable(new string[] { DBEntity.Services.CompanyInfo.ID,
        //            DBEntity.Services.CompanyInfo.CompanyCode,
        //            DBEntity.Services.CompanyInfo.CompanyName
        //            });
        //            string getTableName = DBTables.Company;
        //            DataTable getProjectList = CommonQueryForAll(getTableName, fieldsColumnNames);
        //            foreach (DataRow dataRow in getProjectList.Rows)
        //            {
        //                string outputCode = dataRow[DBEntity.Services.CompanyInfo.CompanyCode].ToString() + " # " + dataRow[DBEntity.Services.CompanyInfo.CompanyName].ToString();
        //                ViewModel.ListCompanies.Add(outputCode);
        //            }
        //        }
        //    }
        //    catch { }
        //}

        //private void LoadListSow()
        //{
        //    try
        //    {
        //        if (ViewModel.ListSow != null && ViewModel.ListSow.Count == 0)
        //        {
        //            ISqlDataService sqlDataService = ContainerService.Instance.Container.Resolve<ISqlDataService>();
        //            string fieldsColumnNames = sqlDataService.GetColumnsForTable(new string[] { DBEntity.Services.Sow.ID,
        //            DBEntity.Services.Sow.Code,
        //            DBEntity.Services.Sow.Description
        //            });
        //            string getTableName = DBTables.Sow;
        //            DataTable getProjectList = CommonQueryForAll(getTableName, fieldsColumnNames);
        //            foreach (DataRow dataRow in getProjectList.Rows)
        //            {
        //                string outputCode = dataRow[DBEntity.Services.Sow.Code].ToString() + " # " + dataRow[DBEntity.Services.Sow.Description].ToString();
        //                ViewModel.ListSow.Add(outputCode);
        //            }
        //        }
        //    }
        //    catch { }
        //}

        //private void LoadListLocations()
        //{
        //    try
        //    {
        //        if (ViewModel.ListLocations != null && ViewModel.ListLocations.Count == 0)
        //        {
        //            ISqlDataService sqlDataService = ContainerService.Instance.Container.Resolve<ISqlDataService>();
        //            string fieldsColumnNames = sqlDataService.GetColumnsForTable(new string[] { DBEntity.Services.Location.ID,
        //            DBEntity.Services.Location.LocationCode,
        //            DBEntity.Services.Location.LocationName
        //            });
        //            string getTableName = DBTables.Location;
        //            DataTable getList = CommonQueryForAll(getTableName, fieldsColumnNames);
        //            foreach (DataRow dataRow in getList.Rows)
        //            {
        //                string outputCode = dataRow[DBEntity.Services.Location.LocationCode].ToString() + " # " + dataRow[DBEntity.Services.Location.LocationName].ToString();
        //                ViewModel.ListLocations.Add(outputCode);
        //            }
        //        }
        //    }
        //    catch { }
        //}

        //private void LoadListProject()
        //{
        //    try
        //    {
        //        if (ViewModel.ListProjects != null && ViewModel.ListProjects.Count == 0)
        //        {

        //            ISqlDataService sqlDataService = ContainerService.Instance.Container.Resolve<ISqlDataService>();
        //            string fieldsColumnNames = sqlDataService.GetColumnsForTable(new string[] { DBEntity.Services.Project.ID,
        //            DBEntity.Services.Project.ProjectCode,
        //            DBEntity.Services.Project.ProjectName
        //            });
        //            string getTableName = DBTables.Project;
        //            DataTable getProjectList = CommonQueryForAll(getTableName, fieldsColumnNames);
        //            foreach (DataRow dataRow in getProjectList.Rows)
        //            {
        //                string outputCode = dataRow[DBEntity.Services.Project.ProjectCode].ToString() + " # " + dataRow[DBEntity.Services.Project.ProjectName].ToString();
        //                ViewModel.ListProjects.Add(outputCode);
        //            }
        //        }
        //    }
        //    catch { }
        //}

        //private void LoadListSubProject()
        //{
        //    try
        //    {
        //        if (ViewModel.ListSubProjects != null && ViewModel.ListSubProjects.Count == 0)
        //        {
        //            ViewModel.ListSubProjects.Add("EE # EntryExit");
        //            ViewModel.ListSubProjects.Add("EVisa # EVisa");
        //            ViewModel.ListSubProjects.Add("VIS # Visitor Information System");
        //        }
        //    }
        //    catch { }
        //}

        //private DataTable CommonQueryForAll(string tableName, string fieldsColumnNames)
        //{
        //    IDBQueries dbQuery = ContainerService.Instance.Container.Resolve<IDBQueries>();
        //    string query = dbQuery.GetSelectDataQuery(tableName, fieldsColumnNames, string.Empty, string.Empty);
        //    string connString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString.ToString();
        //    IDataHelper dtHelper = ContainerService.Instance.Container.Resolve<IDataHelper>();
        //    dtHelper.DBConnectionString = connString;
        //    DataTable List = dtHelper.GetDataTable(query);
        //    return List;
        //}
        #endregion
    }
    public partial class VMTimeSheetLog : ViewModelPresenter<IViewTimeSheetLog, ModelTimeSheetLog>, IVMTimeSheetLog
    {
         #region Constructors

        public VMTimeSheetLog(ViewContext<IViewTimeSheetLog> context)
            : base(context)
        { InitializeObjects(); }

        #endregion
    }
}
