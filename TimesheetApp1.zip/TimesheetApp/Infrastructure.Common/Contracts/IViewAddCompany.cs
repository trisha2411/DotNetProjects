﻿using MyApp.Infrastructure.Interaction.Contracts;

namespace MyApp.Infrastructure.Common.Contracts
{
    public interface IViewAddCompany : IView
    {
    }
}