﻿
namespace MyApp.Infrastructure.Common.Services
{
    public class Constants
    {
    }
}
