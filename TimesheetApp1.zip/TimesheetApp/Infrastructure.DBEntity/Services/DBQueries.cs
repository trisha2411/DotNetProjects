﻿using MyApp.Infrastructure.DBEntity.Contracts;
using System;
using MyApp.Infrastructure.DBEntity.Resources;

namespace MyApp.Infrastructure.DBEntity.Services
{
    public class DBQueries : IDBQueries
    {
        string returnQuery = string.Empty;
        public string GetSelectDataQuery(string tableName, string fields, string joinCondition, string whereCondition)
        {
            try
            {
                if (string.IsNullOrEmpty(joinCondition))
                { joinCondition = string.Empty; }
                if (string.IsNullOrEmpty(whereCondition))
                { whereCondition = string.Empty; }

                returnQuery = DBQuery.SelectData;
                returnQuery = returnQuery.Replace(DBQueriesConstants.fields, fields);
                returnQuery = returnQuery.Replace(DBQueriesConstants.tableName, tableName);
                returnQuery = returnQuery.Replace(DBQueriesConstants.joinCondition, joinCondition);
                returnQuery = returnQuery.Replace(DBQueriesConstants.whereCondition, whereCondition);               
            }
            catch (Exception ex)
            { }
            return returnQuery;
        }
    }
}
