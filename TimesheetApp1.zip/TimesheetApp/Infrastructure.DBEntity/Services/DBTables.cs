﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyApp.Infrastructure.DBEntity.Services
{
    public class DBQueriesConstants
    {
        public const string tableName = "<table>",
            fields = "<fields>",
            joinCondition = "<joinCondition>",
            whereCondition = "<whereCondition>",
            fieldWithValues = "<fieldsWithValue>",
            fieldsValue = "<fieldsValue>";
    }
    public class DBTables
    {
        public const string Login = "Login",
            Project = "Project",
            ProjectSow = "Project_Sow",
            userInfo="UserInfo",
             Company = "CompanyInfo",
              Team = "TeamInfo",
             Sow = "Sow",
             Location = "Location"
            ;
    }

    public class Login
    {
        public const string userName = "UserId",
            password = "Password";        
    }

    public class Project
    {
        public const string ID = "ID",
            ProjectCode = "ProjectCode",
            ProjectName = "ProjectName",
            ParentCode = "ParentCode",
            IsActive = "IsActive";
    }
    public class CompanyInfo
    {
        public const string ID = "ID",
            CompanyCode = "CompanyCode",
            CompanyName = "CompanyName";
    }
    public class TeamInfo
    {
        public const string ID = "ID",
            TeamCode = "TeamCode",
            TeamName = "TeamName";
    }
    public class Location
    {
        public const string ID = "ID",
            LocationCode = "LocationCode",
            LocationName = "LocationName";
    }
    public class Sow
    {
        public const string ID = "ID",
            Code = "Code",
            Description = "Description";
    }

    public class userInfo
    {
        public const string userName = "Username",
            password = "Password";
    }
}
