﻿namespace MyApp.Infrastructure.Unity.Contracts
{
    public interface IContainer 
    { }
}
