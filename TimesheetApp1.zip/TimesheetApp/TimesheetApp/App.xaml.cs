﻿using System.Windows;
using Microsoft.Practices.Unity;
using MyApp.DAL.Contracts;
using MyApp.DAL.Services;
using MyApp.Infrastructure.Bll.ViewModel.Contracts;
using MyApp.Infrastructure.Bll.ViewModel.Services;
using MyApp.Infrastructure.Common.Contracts;
using MyApp.Infrastructure.DBEntity.Contracts;
using MyApp.Infrastructure.DBEntity.Services;
using MyApp.Infrastructure.Unity.Services;
using MyApp.UI.Timesheet.Windows.Main;
using MyApp.UI.Timesheet.Windows.Common;


namespace MyApp.UI.Timesheet
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            RegisterInstances();
        }

        private void RegisterInstances()
        {
            RegisterBllAndDal();
            RegisterViewAndViewModel();
            ResolveRequiredObjects();
        }

        private void RegisterBllAndDal()
        {
            ContainerService.Instance.Container.RegisterType<IDBQueries, DBQueries>();
            ContainerService.Instance.Container.RegisterType<IDataHelper, DataHelper>();
            ContainerService.Instance.Container.RegisterType<ISqlDataService, SqlDataService>();
        }

        private void RegisterViewAndViewModel()
        {
            ContainerService.Instance.Container.RegisterType<IViewLogin, MyApp.UI.Timesheet.Windows.Main.Login>();
            ContainerService.Instance.Container.RegisterType<IViewMain, Mainwin>();
            ContainerService.Instance.Container.RegisterType<IViewNavigation, MyApp.UI.Timesheet.UserControls.Common.UCNavigation>();
            ContainerService.Instance.Container.RegisterType<IViewPopUp, Popup>();
            ContainerService.Instance.Container.RegisterType<IViewTimesheetEntry, MyApp.UI.Timesheet.UserControls.TimesheetEntry>();
            ContainerService.Instance.Container.RegisterType<IViewTimeSheetLog, MyApp.UI.Timesheet.UserControls.Common.UCTimeSheetLog>();
            ContainerService.Instance.Container.RegisterType<IViewEdit, MyApp.UI.Timesheet.UserControls.Common.UCEditControl>();

            ContainerService.Instance.Container.RegisterType<IVMLogin, VMLogin>();
            ContainerService.Instance.Container.RegisterType<IVMMain, VMMain>();
            ContainerService.Instance.Container.RegisterType<IVMNavigation, VMNavigation>();
            ContainerService.Instance.Container.RegisterType<IVMPopUp, VMPopUp>();
            ContainerService.Instance.Container.RegisterType<IVMTimesheetEntry, VMTimesheetEntry>();
            ContainerService.Instance.Container.RegisterType<IVMTimeSheetLog, VMTimeSheetLog>();
            ContainerService.Instance.Container.RegisterType<IVMEdit, VMEdit>();
        }

        private void ResolveRequiredObjects()
        {
            IVMLogin vmlogin = ContainerService.Instance.Container.Resolve<IVMLogin>();
            ((Window)(vmlogin.View)).Show();
        }
    }
}
