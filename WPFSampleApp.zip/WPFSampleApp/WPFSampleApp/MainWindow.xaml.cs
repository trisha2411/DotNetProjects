﻿using System.Windows;
using System.Windows.Controls;
using System;

namespace WPFSampleApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Border_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            StaticCls.Diamentions.Height = e.NewSize.Height / 2;
            StaticCls.Diamentions.Width = e.NewSize.Width / 2;
            //lblHeight.Content = e.NewSize.Height.ToString();
            //lblWidth.Content = e.NewSize.Width.ToString();

            Border border = (Border)sender;
            foreach (object control in ((Grid)border.Child).Children)
            {
                if (control.GetType().Equals(typeof(Grid)))
                {
                    foreach (UserControl childControl in ((Grid)control).Children)
                    {
                        var dataContext = childControl.DataContext;
                        ((IViewModel)dataContext).BorderHeight = Convert.ToInt32(StaticCls.Diamentions.Height);
                        ((IViewModel)dataContext).BorderWidth = Convert.ToInt32(StaticCls.Diamentions.Width);
                    }
                }
            }
        }
    }
}
