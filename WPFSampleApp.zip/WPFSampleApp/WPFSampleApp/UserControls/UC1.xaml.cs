﻿using System.Windows.Controls;

namespace WPFSampleApp.UserControls
{
    /// <summary>
    /// Interaction logic for UC1.xaml
    /// </summary>
    public partial class UC1 : UserControl
    {
        public UC1()
        {
            InitializeComponent();
            AttachDataContext();
        }

        private void AttachDataContext()
        {
            ViewModel.VMuc1 vmUc1 = new ViewModel.VMuc1();
            this.DataContext = vmUc1;
        }
    }
}
