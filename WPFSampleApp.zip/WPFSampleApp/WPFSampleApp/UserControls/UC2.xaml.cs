﻿using System.Windows.Controls;

namespace WPFSampleApp.UserControls
{
    /// <summary>
    /// Interaction logic for UC2.xaml
    /// </summary>
    public partial class UC2 : UserControl
    {
        public UC2()
        {
            InitializeComponent();
            AttachDataContext();
            
        }

        private void AttachDataContext()
        {
            ViewModel.VMuc2 vmUc2 = new ViewModel.VMuc2();
            this.DataContext = vmUc2;
        }

        //private void Border_SizeChanged(object sender, System.Windows.SizeChangedEventArgs e)
        //{
        //    StaticCls.Diamentions.Height = e.NewSize.Height;
        //    StaticCls.Diamentions.Width = e.NewSize.Width;           

        //}
    }
}
