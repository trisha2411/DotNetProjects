﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFSampleApp.ViewModel
{
    public class VMuc2 : ViewModelBase, IViewModel
    {
        private int borderHeight;
        public int BorderHeight
        {
            get { return borderHeight; }
            set
            {
                borderHeight = Convert.ToInt32(StaticCls.Diamentions.Height);
                OnPropertyChanged("BorderHeight");
            }
        }
        private int borderWidth;
        public int BorderWidth
        {
            get { return borderWidth; }
            set
            {
                borderWidth = Convert.ToInt32(StaticCls.Diamentions.Width);
                OnPropertyChanged("BorderWidth");
            }
        }
    }
}
